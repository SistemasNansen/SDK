import os
import re
import zipfile
import time

sdk_ver = "1.3"
re_version = rb"E\..{9}\.\w{2}\.(\w{2})\.\w{2}\.\w{2}"
build_path = ""
config_path = ""
bootloader = ""
gen_ota = ""
zip_path = ""
compress = "tools/easylzma/Linux/x86_64/elzma -k -s 65536 -v -f "
upgrade_path = "build/upgrade/"
if  sdk_ver == "1.7":
    build_file = "main2.bin"
elif sdk_ver == "1.3":
    build_file = "main.bin"
flash_file = "vc7300*"

def gen_remote_file(data):
    match = re.search(re_version, data)
    version = match.group()
    print(version)
    new_version = upgrade_path + version.decode() + ".bin"
    with open(new_version, "wb") as f:
        f.write(data)
    if  sdk_ver == "1.7":
        os.system("tools/upgrade/add_header "+ new_version)
    os.system(compress + new_version)

    compress_version = upgrade_path + version.decode() + ".bin.lzma"
    with open(compress_version, "rb+") as f:
        content = f.read()
        f.seek(0, 0)
        data = b"vtxc" + content
        f.write(data)
    os.system(gen_ota + " " + compress_version)
    os.system("mv image_for_upgrade.bin " + upgrade_path + "remote_upgrade/"
              "remote_"+sdk_ver+"_"+version.decode()+".bin")
    os.system("rm " + new_version)
    os.system("rm " + compress_version)
    os.system("cp " + build_path + "main.map" + " " + upgrade_path)
    os.system("cp " + build_path + "main.elf" + " " + upgrade_path)
    os.system("cp " + config_path + " " + upgrade_path)

#打包目录为zip文件（未压缩）
def make_zip(source_dir, output_filename):
    zipf = zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED)    
    pre_len = len(os.path.dirname(source_dir))
    for parent, dirnames, filenames in os.walk(source_dir):
        for filename in filenames:
            pathfile = os.path.join(parent, filename)
            arcname = pathfile[pre_len:].strip(os.path.sep)     #相对路径
            zipf.write(pathfile, arcname)
    zipf.close()

with open(".config", "r") as f:
    data = f.read()
    if  sdk_ver == "1.7":
        if re.findall("CONFIG_WISUN_ROOT=y", data):
            path = "build/"
            config_name = "root_vc7300BHDK_ota_config"
            zip_path = "build/BR_"+time.strftime("%Y%m%d_%H%M", time.localtime()) +".zip"
        else:
            path = "build/"
            config_name = "node_vc7300BHDK_ota_config"
            zip_path = "build/LN_"+time.strftime("%Y%m%d_%H%M", time.localtime()) +".zip"
    elif sdk_ver == "1.3":
        if re.findall("CONFIG_WISUN_ROOT=y", data):
            path = "build/"
            config_name = "root_vc7300RFGMADP_ota_config"
            zip_path = "build/BR_"+time.strftime("%Y%m%d_%H%M", time.localtime()) +".zip"
        else:
            path = "build/"
            config_name = "node_vc7300BMTR_ota_config"
            zip_path = "build/LN_"+time.strftime("%Y%m%d_%H%M", time.localtime()) +".zip"
    build_path = path + "main/"
    bootloader = path + "bootloader/bootloader_16K.bin"
    config_path = build_path + config_name
    gen_ota = "tools/upgrade/gen_ota_image.sh " + config_path

os.system("rm -rf " + upgrade_path)
os.system("mkdir -p " + upgrade_path + "local_flash")
os.system("mkdir -p " + upgrade_path + "remote_upgrade")
os.system("cp .config " + upgrade_path)
os.system("cp "+ build_path+build_file + " " + upgrade_path)

with open(build_path+build_file, "rb") as f:
    data = bytearray(f.read())
    
    match = re.search(re_version, data)
    version = match.group().decode()
    os.system("cp "+ "build/"+flash_file + " " + upgrade_path + "local_flash/local_"+sdk_ver+"_"+version+".bin")
    gen_remote_file(data)

    matches = re.finditer(re_version, data)
    for matchNum, match in enumerate(matches, start=1):
        print("Match {matchNum} was found at {start}-{end}: {match}".format(
            matchNum=matchNum, start=match.start(), end=match.end(), match=match.group()))

        for groupNum in range(0, len(match.groups())):
            groupNum = groupNum + 1

            print("Group {groupNum} found at {start}-{end}: {group}".format(groupNum=groupNum,
                                                                            start=match.start(groupNum), end=match.end(groupNum), group=match.group(groupNum)))
            data[match.start(groupNum)] = b"B"[0]
    gen_remote_file(data)
# make_zip(upgrade_path, zip_path)
