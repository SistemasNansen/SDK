/**
 * Copyright (c) 2018 Vertexcom Technologies, Inc. All rights reserved
 * Vertexcom Confidential Proprietary
 *
*/

#ifndef _HEAP_H_
#define _HEAP_H_

#include <stddef.h>

void *vc_heap_alloc( size_t xWantedSize, void* caller );
void vc_heap_free( void *pv );
size_t vc_heap_get_total_size( void );
size_t vc_heap_get_remain_size( void );
size_t vc_heap_get_minever_remain_size( void );
void vc_heap_dump(void);
void vc_heap_dump_in_fault(void);
void vc_heap_diagnostic(void);
int vc_heap_used_check_crash(void);

#endif
