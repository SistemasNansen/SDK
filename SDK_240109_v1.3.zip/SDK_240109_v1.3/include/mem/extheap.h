/**
 * Copyright (c) 2018 Vertexcom Technologies, Inc. All rights reserved
 * Vertexcom Confidential Proprietary
 *
*/

#ifndef _EXTHEAP_H_
#define _EXTHEAP_H_

#include <stddef.h>

void vc_extheap_init(void);
void *vc_extheap_alloc( size_t xWantedSize, void* caller );
void vc_extheap_free( void *pv );
size_t vc_extheap_get_total_size( void );
size_t vc_extheap_get_remain_size( void );
size_t vc_extheap_get_minever_remain_size( void );
void vc_extheap_dump(void);
void vc_extheap_dump_in_fault(void);
void vc_extheap_diagnostic(void);

#endif
