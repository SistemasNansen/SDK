/**
 * Copyright (c) 2018 Vertexcom Technologies, Inc. All rights reserved
 * Vertexcom Confidential Proprietary
 *
*/

#ifndef __VC_SYSTICK_H
#define __VC_SYSTICK_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SYSTICK_USE_RTC
void vcsystick_config_ms(void);

void vcsystick_config_int_enable(uint32_t priority);

void vcsystick_config_int_disable(void);

uint32_t vcsystick_get_ms_now(void);

uint32_t vcsystick_get_ms_residueQ5(void);

uint32_t vcsystick_set_ms_alarm(uint32_t ms);

uint32_t vcsystick_get_ms_alarm_now(void);

void vcsystick_wait_ms(uint32_t ms);

uint32_t vcsystick_get_us_now(void);

void vcsystick_wait_us(uint32_t us);

void vcsystick_isr(void);

void vcsystick_update(uint32_t count);



#ifdef __cplusplus
}
#endif

#endif // __VC_SYSTICK_H

