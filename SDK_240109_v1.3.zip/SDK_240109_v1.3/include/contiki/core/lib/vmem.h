/**
 * Copyright (c) 2018 Vertexcom Technologies, Inc. All rights reserved
 * Vertexcom Confidential Proprietary
 *
*/


#ifndef _VMEM_H_
#define _VMEM_H_

typedef enum{
	_VMEM_C_,
	_VMEM_XX_C_,
    _DHCP6S_C_,
    _WISUN_RPL_C_,
    _WISUN_QUEUE_C_,
    _VERTEXCOM_SNMP_C_,
    _WISUN_MAC_C_,
    _VC_PKTHANDLER_COAPHANDLER_C_,
    _WISUN_STATE_C_,
    _EAPOL_C_,
    _EAPOL_EAP_C_,
    _EAPOL_KEY_C_,
    _EAPOL_RELAY_C_,
    _WISUN_SEC_C_,
    _WISUN_TLS_C_,
    _WISUN_CRYPT_C_,
    _SHELL_PING6_C_,
    _ATCMD_RES_C_,
	TOTAL_MEM_FILE_CODE
}mem_file_code;

#define vmem_alloc(size)\
	vc_mem_alloc(size, __FILE_CODE__, __LINE__)
#define vmem_free(ptr)\
	vc_mem_free(ptr)

#if CONTIKI_WITH_VMEM
void *vc_get_mem(int size);
void *vc_mem_alloc(int size, unsigned int file, unsigned int line);
void vc_mem_free(void *ptr);
void vc_mem_dump(int all);
//void vmem_init(void);
void shell_vmem_init(void);
#else
#define vc_get_mem(...) NULL
#define vc_mem_alloc(...) NULL
#define vc_mem_free(...)
#define vc_mem_dump(...)
#define vmem_init(...)
#define shell_vmem_init(...)
#endif
#endif


