/**
 * Copyright (c) 2018 Vertexcom Technologies, Inc. All rights reserved
 * Vertexcom Confidential Proprietary
 *
*/

#ifndef BITMAP_H_
#define BITMAP_H_

// bitmap tool api
#define BITMAP_INVALID 0xffff
#define SET_BIT(x, n) ((x) |= (1 << (n)))
#define GET_BIT(x, n) (((x) >> (n)) & 1)
#define CLR_BIT(x, n) ((x) &= ~(1 << (n)))

uint16_t bitmap_take_free(uint32_t *table, uint16_t max, uint8_t peek);
void bitmap_print(uint32_t *table, uint16_t max);
uint32_t *bitmap_adjust(uint32_t *table, uint16_t old_max, uint16_t new_max);

// give the bit back to bitmap
static inline uint16_t bitmap_give(uint32_t *table, uint16_t bit, uint16_t max)
{
    if (table && bit < max)
        CLR_BIT(table[bit >> 5], bit % 32);
    else
        bit = BITMAP_INVALID;
    return bit;
}

// take the bit from bitmap
static inline uint16_t bitmap_take(uint32_t *table, uint16_t bit, uint16_t max)
{
    if (table && bit < max)
        SET_BIT(table[bit >> 5], bit % 32);
    else
        bit = BITMAP_INVALID;
    return bit;
}

static inline uint16_t bitmap_get(uint32_t *table, uint16_t bit, uint16_t max)
{
    return ((table && bit < max) ? GET_BIT(table[bit >> 5], bit % 32) : BITMAP_INVALID);
}

uint32_t *bitmap_alloc(uint16_t max);

static inline void bitmap_free(uint32_t *bitmap)
{
    free((void *)bitmap);
}

#endif /* BITMAP_H_ */
