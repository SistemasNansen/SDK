 /**
  * Copyright (c) 2018 Vertexcom Technologies, Inc. All rights reserved
  * Vertexcom Confidential Proprietary
  *
 */
#include <stdint.h>
#include <lib/list.h>

#ifndef __WISUN_RPL_HASH_H__
#define __WISUN_RPL_HASH_H__

typedef struct hlist_head {
  LIST_STRUCT(head);
}hlist_head;
 
typedef struct hlist {
  int size;
  hlist_head *tbl;
  int (*hash)(uint8_t *key, uint32_t length);
}hlist;
 
typedef struct hlist * hlist_t;

#endif


#define H_LIST(name,hsize,hhash) 																\
	static hlist_head LIST_CONCAT(name,_hlist)[hsize];											\
	static hlist name = {.tbl = LIST_CONCAT(name,_hlist), .size = hsize, .hash = hhash};		\

#define H_LIST_STRUCT(sname,ssize)											\
	hlist_head LIST_CONCAT(sname,_hlist)[ssize];							\
	hlist sname;															\

int    jen_hash(uint8_t *key, uint32_t length);
void   hash_list_init(hlist_t hlist);
void * hash_list_head(hlist_t hlist);
void * hash_list_head_from_key(hlist_t hlist, uint8_t *key, int len);
void * hash_list_head_from_index(hlist_t hlist, int index);
int   hash_list_add(hlist_t hlist, void *item, uint8_t *key, int len);
int   hash_list_remove(hlist_t hlist, void *item, uint8_t *key, int len);
int	   hash_list_length(hlist_t hlist);
void * hash_list_item_next(hlist_t hlist, void *item, uint8_t *key, int len);
void * hash_list_tail(hlist_t hlist);