/**
 * Copyright (c) 2018 Vertexcom Technologies, Inc. All rights reserved
 * Vertexcom Confidential Proprietary
 *
*/


#ifndef _BASE64_H_
#define _BASE64_H_

int base64_encode(uint8_t *output, uint16_t output_max, uint8_t *input, uint16_t input_len);
int base64_decode(uint8_t *output, uint16_t output_max, uint8_t *input, uint16_t input_len);

#endif


