/**
 * Copyright (c) 2018 Vertexcom Technologies, Inc. All rights reserved
 * Vertexcom Confidential Proprietary
 *
*/

#ifndef __NET_CONF_H
#define __NET_CONF_H

/*****************************************************************************/
/* NATIVE Netstack configuration --------------------------------------------*/
/*****************************************************************************/
#if !NETSTACK_CONF_WITH_WISUN

#ifndef NETSTACK_CONF_NETWORK
#if NETSTACK_CONF_WITH_IPV6
#define NETSTACK_CONF_NETWORK                   sicslowpan_driver
#else
#define NETSTACK_CONF_NETWORK                   rime_driver
#endif
#endif

#ifndef NETSTACK_CONF_MAC
#define NETSTACK_CONF_MAC                       csma_driver
#endif

#ifndef NETSTACK_CONF_RDC_CHANNEL_CHECK_RATE
#define NETSTACK_CONF_RDC_CHANNEL_CHECK_RATE    8
#endif

#ifndef NETSTACK_CONF_FRAMER
#define NETSTACK_CONF_FRAMER                    framer_802154
#endif

#ifndef NETSTACK_CONF_RADIO
#define NETSTACK_CONF_RADIO                     centauri_driver
#endif

#ifndef NETSTACK_CONF_RDC
#define NETSTACK_CONF_RDC                       nullrdc_driver
#endif

/* CSMA CONFIGURATION ----------------------------------------------------- */
/* 802.15.4 2006: */
#ifndef CSMA_CONF_MIN_BE
#define CSMA_CONF_MIN_BE                        3
#endif

#ifndef CSMA_CONF_MAX_BE
#define CSMA_CONF_MAX_BE                        5
#endif

#ifndef CSMA_CONF_MAX_BACKOFF
#define CSMA_CONF_MAX_BACKOFF                   4
#endif

#ifndef CSMA_CONF_MAX_FRAME_RETRIES
#define CSMA_CONF_MAX_FRAME_RETRIES             3
#endif

/* ------------------------------------------------------------------------ */
#ifndef LINKADDR_CONF_SIZE
#define LINKADDR_CONF_SIZE                      8
#endif

/*****************************************************************************/
/* WISUN Netstack configuration ---------------------------------------------*/
/*****************************************************************************/
#else

/* TODO: Need to modify to fit WISUN spec */

#ifndef NETSTACK_CONF_NETWORK
#if NETSTACK_CONF_WITH_IPV6
#define NETSTACK_CONF_NETWORK                   sicslowpan_driver
#else
#define NETSTACK_CONF_NETWORK                   rime_driver
#endif
#endif

#ifndef NETSTACK_CONF_MAC
#define NETSTACK_CONF_MAC                       csma_driver
#endif

#ifndef NETSTACK_CONF_RDC_CHANNEL_CHECK_RATE
#define NETSTACK_CONF_RDC_CHANNEL_CHECK_RATE    8
#endif

#ifndef NETSTACK_CONF_FRAMER
#define NETSTACK_CONF_FRAMER                    framer_802154
#endif

#ifndef NETSTACK_CONF_RADIO
#define NETSTACK_CONF_RADIO                     centauri_driver
#endif

#if CONFIG_WISUN_DUAL_MODE
#ifndef NETSTACK_CONF_PLC
#define NETSTACK_CONF_PLC						hplc_driver
#endif
#endif

#ifndef NETSTACK_CONF_RDC
#define NETSTACK_CONF_RDC                       nullrdc_driver
#endif

/* CSMA CONFIGURATION ----------------------------------------------------- */
/* 802.15.4 2006: */
#ifndef CSMA_CONF_MIN_BE
#define CSMA_CONF_MIN_BE                        3
#endif

#ifndef CSMA_CONF_MAX_BE
#define CSMA_CONF_MAX_BE                        5
#endif

#ifndef CSMA_CONF_MAX_BACKOFF
#define CSMA_CONF_MAX_BACKOFF                   4
#endif

#ifndef CSMA_CONF_MAX_FRAME_RETRIES
#define CSMA_CONF_MAX_FRAME_RETRIES             3
#endif

/* ------------------------------------------------------------------------ */
#ifndef LINKADDR_CONF_SIZE
#define LINKADDR_CONF_SIZE                      8
#endif

#ifndef UIP_CONF_LL_802154
#define UIP_CONF_LL_802154                      1
#endif

#endif
#endif /* __NETWORK_CONF_H */
