/**
 * Copyright (c) 2018 Vertexcom Technologies, Inc. All rights reserved
 * Vertexcom Confidential Proprietary
 *
*/

#ifndef __CONTIKI_CONF_H__
#define __CONTIKI_CONF_H__

#include <stdint.h>
#include <string.h>

/*---------------------------------------------------------------------------*/
/* Include Project Specific conf */
#ifdef PROJECT_CONF_H
#include PROJECT_CONF_H
#endif /* PROJECT_CONF_H */

/* Net specific configuration */
#include "net-conf.h"

/*---------------------------------------------------------------------------*/

/* Compiler configurations */
#define CC_CONF_REGISTER_ARGS          0
#define CC_CONF_FUNCTION_POINTER_ARGS  1
#define CC_CONF_FASTCALL
#define CC_CONF_VA_ARGS                1
#define CC_CONF_INLINE                 inline

#define CCIF
#define CLIF

#ifndef U8_TYPE
#define U8_TYPE
typedef uint8_t u8_t;
#endif
#ifndef U16_TYPE
#define U16_TYPE
typedef uint16_t u16_t;
#endif
#ifndef U32_TYPE
#define U32_TYPE
typedef uint32_t u32_t;
#endif
#ifndef S32_TYPE
#define S32_TYPE
typedef int32_t s32_t;
#endif

typedef uint32_t clock_time_t;
typedef uint32_t uip_stats_t;

typedef uint32_t rtimer_clock_t;
#define RTIMER_CLOCK_DIFF(a,b)         ((int32_t)((a)-(b)))

#define CLOCK_CONF_SECOND              1000  /* 1 ticks / 1ms */
#define CLOCK_TICKS_MS                 1

#define RTIMER_ARCH_SECOND             1000
#define ABS_OFFSET_U32(old, new) (1UL + new + (0xffffffffUL - old)) //Absolute offset from old to new

extern void nvramVarStore(void);
#define __NVRAM_VAR__                  __attribute__((section(".nvram_data")))

#ifdef CONFIG_BUILD_WITH_VCRTOS
extern uint32_t vcsystick_get_ms_now(void);
extern uint32_t vcsystick_get_us_now(void);
#endif

#endif /* __CONTIKI_CONF_H__ */
