#ifndef _SDK_WISUN_H_
#define _SDK_WISUN_H_

#include "types.h"
#include "sdk_socket.h"

struct wisun_hook_fn_table {
    void (*rpl_join_callback_fn)(const uip_ipaddr_t *device, const uip_ipaddr_t *parent, uint8_t changed, uint8_t level);
    void (*rpl_leave_callback_fn)(const uip_ipaddr_t *device);
};

typedef struct
{
    uint8_t net_state;
    uip_ipaddr_t local_ip;
    uip_ipaddr_t parent_ip;
    uint8_t level;
    uint8_t changed;
} wisun_struct;

enum
{
    E_NET_STATE_OFFLINE = 0,
    E_NET_STATE_ONLINE = 1,
};

enum
{
    E_AUTH_NONE = 0,
    E_AUTH_LOW = 1,
    E_AUTH_HIGH = 2,
};

enum
{
    E_EVENT_LN_UPGRADE_SUCCESS = 1,
    E_EVENT_LN_UPGRADE_FAIL = 2,
    E_EVENT_LN_POWERON = 3,
    E_EVENT_LN_POWERDOWN = 4,
    E_EVENT_BR_UPGRADE_SUCCESS = 1001,
    E_EVENT_BR_UPGRADE_FAIL = 1002,
    E_EVENT_BR_BROADCAST_START = 1003,
    E_EVENT_BR_BROADCAST_END = 1004,
    E_EVENT_BR_JOINTABLE_DELETE_SUCCESS = 1006,
};

extern wisun_struct wisun;
extern struct wisun_hook_fn_table WISUN_HOOK;
extern char software_version[32];
extern char vendor_version[32];
extern uint8_t auth_type;

void coap_send_event(void * ptr);
void wisun_auth_type(uint8_t type);
uint32_t wisun_get_sn();
void wisun_set_mac(uint8_t *mac, uint8_t len);
uint8_t *wisun_get_mac(void);
void wisun_set_panid(uint16_t id);
uint16_t wisun_get_panid();
uint8_t wisun_set_netname(char *netname);
char *wisun_get_netname(void);
uint16_t wisun_get_rftest_mode(void);
uint8_t wisun_set_software(char* software);
char *wisun_get_software();
uint8_t wisun_set_vendor(char* vendor);
char * wisun_get_vendor();
void wisun_set_factory(uint8_t mode);
uint8_t wisun_get_factory(void);
void wisun_set_frequence(uint16_t band_num);
uint32_t wisun_get_frequence(void);
void wisun_start_register(void);
void wisun_reboot(void);
unsigned short random_rand(void);
void wisun_reset_board_id(void);
#endif
