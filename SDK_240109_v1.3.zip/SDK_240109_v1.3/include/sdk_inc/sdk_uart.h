#ifndef _SDK_UART_H_
#define _SDK_UART_H_

#define UARTPARITY_EVEN     0
#define UARTPARITY_ODD      1
#define UARTPARITY_0        2
#define UARTPARITY_1        3
#define UARTPARITY_NONE     4
typedef void (*recv_handler_cb)(const char *data, unsigned int len);

void timerUart_init(uint32_t baudrate, uint8_t parity, recv_handler_cb recv_fx);

int timerUart_write(const void *_ptr, int _len);
#endif