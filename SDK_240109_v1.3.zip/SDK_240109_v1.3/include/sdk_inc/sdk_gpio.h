/**
 * Copyright (c) 2018 Vertexcom Technologies, Inc. All rights reserved
 * Vertexcom Confidential Proprietary
 *
*/

#ifndef SDK_GPIO_H
#define SDK_GPIO_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define IOA 0
#define IOB 1
#define IOC 2
#define IOD 3
#define IOE 4

#define IODETECT_RISING   0
#define IODETECT_FALLING  1
#define IODETECT_HIGH     2
#define IODETECT_LOW      3
#define IODETECT_EDGEBOTH 4

#define PULL_DOWN 0
#define PULL_HIGH 1

void hal_gpio_input_init(uint8_t port, uint8_t pin);
void hal_gpio_input_init_pull(uint8_t port, uint8_t pin, uint8_t pull);
void hal_gpio_output_init(uint8_t port, uint8_t pin);
void hal_gpio_output_init_pull_up(uint8_t port, uint8_t pin);
int hal_gpio_read_output_bit(uint8_t port, uint8_t pin);
void hal_gpio_high(uint8_t port, uint8_t pin);
void hal_gpio_low(uint8_t port, uint8_t pin);
void hal_gpio_toggle(uint8_t port, uint8_t pin);
int hal_gpio_get_input_status(uint8_t port, uint8_t pin);
void set_tx_led(uint8_t port, uint8_t pin);
void set_rx_led(uint8_t port, uint8_t pin);
#ifdef __cplusplus
}
#endif

#endif // HAL_GPIO_H

