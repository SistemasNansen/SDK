#!/bin/bash

# Common Header Format:
#  0                   1                   2                   3
#  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# | V |  RSV  |S|A|    HDR Len    |           CHKSUM              |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                           Total Len                           |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |      MCU      |    Board      |      Role     |    Reserved   | 
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |        Reboot Delay Time      |     CoAP Send Interval        |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

# Config Example 0 [only schedule_ota_time in 4 bytes ntp time]
# schedule_ota_time=12345678
#
# Config Example 1 [2 rules, one for (PAN 788 IP 0001(hex) and 01A3(hex)) and the other (PAN 799 IP 0200(hex)); and set schedule_ota_time]
# PANID_CNT=2
# PANID0=788
# IP0=000101A3
# PANID1=799
# IP1=0200
# schedule_ota_time=12345678
#
# Config Example 2 [2 rules, one for all PAN 799 and the other for (PAN 788 IP 0001(hex) and 01A3(hex)); and set schedule_ota_tim)]
# PANID_CNT=2
# PANID0=799
# PANID1=788
# IP1=000101A3
# schedule_ota_time=12345678
#
# Config Example 3 [3 rules, one for all PAN 797, and one for (PAN 798 IP 0001(hex) and 01A3(hex)), one for (PAN 799 IP BITMAP 78); and set schedule_ota_time
# IP_BITMAP2=78 => 0X1111000, [ip6][ip5][ip4][ip3][ip2][ip1][ip0]
# PANID_CNT=3
# PANID0=797
# PANID1=798
# IP1=000101A3
# PANID2=799
# IP_BITMAP2=78
# schedule_ota_time=12345678

PANID_CNT=0
IMAGE_FILE=$1
source $2
NEW_IMAGE_FILE=$1.new
IMAGE_FILE_SIZE=$(stat -c%s "$IMAGE_FILE")
#ver/reserved/auto_reboot
TMP=`xxd -l 1 -ps -s 0 $IMAGE_FILE`
TMP=`printf %d 0x$TMP`
V=$[(TMP>>6)&3]
SP=$[(TMP>>1)&1]
A=$[TMP&1]
HDR_LEN=`xxd -l 1 -ps -s 1 $IMAGE_FILE`
HDR_LEN=`printf %d 0x$HDR_LEN`
CHKSUM=`xxd -l 2 -ps -s 2 $IMAGE_FILE`
CHKSUM=0x$CHKSUM
TOTAL_LEN=`xxd -l 4 -ps -s 4 $IMAGE_FILE`
TOTAL_LEN=`printf %d 0x$TOTAL_LEN`
MCU=`xxd -l 1 -ps -s 8 $IMAGE_FILE`
MCU=`printf %d 0x$MCU`
BOARD=`xxd -l 1 -ps -s 9 $IMAGE_FILE`
BOARD=`printf %d 0x$BOARD`
ROLE=`xxd -l 1 -ps -s 10 $IMAGE_FILE`
ROLE=`printf %d 0x$ROLE`
REBOOT_DELAY=`xxd -l 2 -ps -s 12 $IMAGE_FILE`
REBOOT_DELAY=`printf %d 0x$REBOOT_DELAY`
COAP_INTERVAL=`xxd -l 2 -ps -s 14 $IMAGE_FILE`
COAP_INTERVAL=`printf %d 0x$COAP_INTERVAL`

echo VER=$V SP=$SP AUTO_REBOOT=$A CHKSUM=$CHKSUM
echo TOTAL_LEN=$TOTAL_LEN
echo MCU=$MCU BOARD=$BOARD ROLE=$ROLE
echo REBOOT_DELAY_TIME=$REBOOT_DELAY
echo COAP_SEND_INTERVAL=$COAP_INTERVAL

[ $IMAGE_FILE_SIZE == "0" ] && echo IMAGE_FILE_SIZE error && exit 1
[ $HDR_LEN != "16" ] && echo HDR_LEN error && exit 1
[ $TOTAL_LEN != $IMAGE_FILE_SIZE ] && echo TOTAL_LEN error && exit 1

PAYLOAD_SIZE=$[TOTAL_LEN-HDR_LEN]

# Update HDR_LEN and TOTAL_LEN
i=0
TMP=$[PANID_CNT<<2]
HDR_LEN=$[HDR_LEN+TMP]
while [ $i -lt $PANID_CNT ]
do
	eval "IP=\$IP$i"
	eval "IP_BITMAP=\$IP_BITMAP$i"
	if [ "$IP" != "" ]; then
		TMP=$IP
	else
		TMP=$IP_BITMAP
	fi
	if [ "$TMP" != "" ]; then
		TMP=${#TMP}
		HDR_LEN=$[HDR_LEN+2+TMP/2]
	fi
	i=$[i+1]
done

eval "schedule_ota_time=\$schedule_ota_time"
if [ "$schedule_ota_time" != "" ]; then
	HDR_LEN=$[HDR_LEN+6]
fi

TOTAL_LEN=$[HDR_LEN+PAYLOAD_SIZE]

[ $HDR_LEN -gt "255" ] && echo ERR: HDR_LEN=$HDR_LEN greater than 255 && exit 1

#Generate New Image
OUT=`xxd -l 1 -ps -s 0 $IMAGE_FILE`
OUT=$OUT`printf %02X $HDR_LEN`
OUT=$OUT`xxd -l 2 -ps -s 2 $IMAGE_FILE`
OUT=$OUT`printf %08X $TOTAL_LEN`
if [ "$COAP_SEND_INTERVAL" == "" ]; then
	OUT=$OUT`xxd -l 8 -ps -s 8 $IMAGE_FILE`
else
	OUT=$OUT`xxd -l 6 -ps -s 8 $IMAGE_FILE`
	OUT="$OUT"`printf %04X $COAP_SEND_INTERVAL`
fi
i=0
while [ $i -lt $PANID_CNT ]
do
	eval "PANID=\$PANID$i"
	OUT="$OUT"AA02`printf %04X $PANID`
        eval "IP=\$IP$i"
        eval "IP_BITMAP=\$IP_BITMAP$i"
        if [ "$IP" != "" ]; then
        	OUT="$OUT"AC
		TMP=$IP
	else
		TMP=
		if [ "$IP_BITMAP" != "" ]; then
			OUT="$OUT"AB
			TMP_LEN=${#IP_BITMAP}
			while [ $TMP_LEN -gt 0 ]
			do
				TMP_LEN=$[TMP_LEN-2]
				TMP=$TMP"${IP_BITMAP:$TMP_LEN:2}"
			done
		fi
        fi
	if [ "$TMP" != "" ]; then
		TMP_LEN=${#TMP}
		TMP_LEN=$[TMP_LEN/2]
		OUT="$OUT"`printf %02X $TMP_LEN`"$TMP"
	fi
	i=$[i+1]
done

eval "schedule_ota_time=\$schedule_ota_time"
if [ "$schedule_ota_time" != "" ]; then
	OUT="$OUT"AD04`printf %08X $schedule_ota_time`
fi

OUT=$OUT`xxd -l $PAYLOAD_SIZE -ps -s 16 $IMAGE_FILE`
echo $OUT | xxd -r -p > $NEW_IMAGE_FILE

