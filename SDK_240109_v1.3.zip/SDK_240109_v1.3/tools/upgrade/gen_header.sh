#!/bin/bash

source $1 
IMAGE_FILE=$2
CRC16=$(dirname $0)/crc16_ccitt
BIN_HDR_FILE=OTA_HDR_FILE

OUT=
#ver/reserved/auto_reboot
VA=$[((ver%4) << 6) | ((spread%2) << 1) | (auto_reboot%2)]
OUT=$OUT`printf %02X $VA`

#HDR LEN
HDR_LEN=16
if [ "$panid" != "" ]; then
	HDR_LEN=$[HDR_LEN+4]
fi

if [ "$ip_bitmap" != "" ]; then
	BITMAP_LEN=${#ip_bitmap}
	BITMAP_LEN=$[BITMAP_LEN/2]
	HDR_LEN=$[HDR_LEN+2+BITMAP_LEN]
fi
#HDR_LEN
OUT=$OUT`printf %02X $HDR_LEN`
#CHKSUM
CHKSUM=`$CRC16 $IMAGE_FILE`
OUT=$OUT`printf %04X $CHKSUM` 
#TOTAL_LEN
TOTAL_LEN=$(stat -c%s "$IMAGE_FILE")
TOTAL_LEN=$[TOTAL_LEN+HDR_LEN]
OUT=$OUT`printf %08X $TOTAL_LEN`
#MCU
OUT=$OUT`printf %02X $mcu`
#BOARD
OUT=$OUT`printf %02X $board`
#ROLE
OUT=$OUT`printf %02X $role`
#Reserved
OUT="$OUT"00
#auto_reboot_delay
OUT=$OUT`printf %04X $auto_reboot_delay`
#coap_send_interval
OUT=$OUT`printf %04X $coap_send_interval`

if [ "$panid" != "" ]; then
	OUT="$OUT"AA02`printf %04X $panid`
fi

if [ "$ip_bitmap" != "" ]; then
	OUT="$OUT"AB`printf %02X $BITMAP_LEN`"$ip_bitmap"
fi

echo $OUT | xxd -r -p > $BIN_HDR_FILE
#echo OUT=$OUT

