#!/bin/bash
ARG_PATH=$(dirname $0)
if [ -z "$ARG_PATH/gen_header.sh" ]; then
	echo "no gen_header utility"
else
	if [ -z "$1" ]; then
		echo "no config file input"
	else
		if [ -z "$2" ]; then
			echo "no image input"
		else
			$ARG_PATH/gen_header.sh $1 $2
			cat OTA_HDR_FILE $2 > image_for_upgrade.bin
			rm OTA_HDR_FILE
		fi
	fi
fi
