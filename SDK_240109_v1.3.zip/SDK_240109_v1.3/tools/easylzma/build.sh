#!/bin/bash

os=$(uname)
arch=$(uname -m)

if ! type "cmake" > /dev/null; then
	echo "please install cmake by sudo apt-get install cmake"
else
	rm -Rf build/
	mkdir -p build/
	cd build && cmake ../ && make
	cd ..
	mkdir -p $os/$arch
	cp -f build/elzma/elzma $os/$arch/
	rm -Rf build/
fi
