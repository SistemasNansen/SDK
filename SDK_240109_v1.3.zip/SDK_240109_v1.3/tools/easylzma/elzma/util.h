#ifndef __UTIL_H__
#define __UTIL_H__

/* delete a file, nonzero on failure */
int deleteFile(const char * fname);

#endif
