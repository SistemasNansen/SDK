
#include <stdio.h>
#include <inttypes.h>
#include <string.h>

#include "contiki.h"
#include "sdk_wisun.h"
#include "sdk_gpio.h"

#include "app.h"
#include "app_type.h"
#include "app_dyinggasp.h"

struct ctimer ct_dyinggasppost_timer;
struct ctimer ct_poweronpost_timer;
static int event;

PROCESS(apps_dyinggasp_process, "apps dyinggasp process");


void App_dyinggasppost_Callback(void *parma)
{
	// uint16_t fcs;

	SrApp.PowerOnState = 0; //上电标记清零

	// process_post(&sr_apps_main_process, PROCESS_EVENT_POWERDOWNREPORT, NULL);
	printf("Post Powerdown Event\n");
	event = E_EVENT_LN_POWERDOWN;
	coap_send_event(&event);
}

void App_EnergyReturnpost_Callback(void *param)
{
}

PROCESS_THREAD(apps_dyinggasp_process, ev, data)
{
    static struct etimer et2;
    uint32 postdelay;
    // uint32 delayunit;
    uint16 shortIp;
    PROCESS_BEGIN();

    /* start your application here */

    hal_gpio_input_init(APP_DYINGGASP_EVENT_PORT, APP_DYINGGASP_EVENT_PIN);

    etimer_set(&et2, CLOCK_SECOND / 10); // 开启100毫秒定时器
    printf("@App_sr_apps_dyinggasp_process Start\r\n");

    while (1)
    {
        PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&et2));

        if (0 == hal_gpio_get_input_status(APP_DYINGGASP_EVENT_PORT, APP_DYINGGASP_EVENT_PIN))
        {
            ctimer_stop(&ct_poweronpost_timer);

            if (SrApp.DyingState == 0)
            {
                SrApp.DyingState = 1; // 掉电预警
            }
            else if (SrApp.DyingState == 1)
            {
                // 程序运行到这里，代表检测到掉电状态已经过200ms
                SrApp.DyingState = 2; // 掉电确认

                if (wisun.net_state == E_NET_STATE_ONLINE)
                {
                    // delayunit = 100; //单位为1秒
                    // shortIp = (SrApp.LocalIp[14] << 8) + SrApp.LocalIp[15];
                    // // if (shortIp > 2 && shortIp < 3003)
                    // // {
                    // postdelay = (0x0000FFFF & (shortIp - 2)) * delayunit;													//根据IP地址的后16位计算延时上报时间,IP地址减2是因为表端IP地址是从3开始的
                    postdelay = random_rand() % (100 * CLOCK_SECOND); // 根据IP地址的后16位计算延时上报时间,IP地址减2是因为表端IP地址是从3开始的
                    printf("@App_PowerDown delay: %ld \r\n", postdelay);
                    ctimer_set(&ct_dyinggasppost_timer, (40 * CLOCK_SECOND) + postdelay, App_dyinggasppost_Callback, NULL); // 掉电后延时40S才开始离散上报
                    // }
                }
            }
            else
            {
            }
        }
        else
        {
            SrApp.DyingState = 0; // 清掉电标记
            ctimer_stop(&ct_dyinggasppost_timer);
            if (SrApp.PowerOnState == 0)
            {
                SrApp.PowerOnState = 1;
            }
            else if (SrApp.PowerOnState == 1)
            {
                SrApp.PowerOnState = 2; // 上电确认
            }
            else if (SrApp.PowerOnState == 2)
            {
                if (wisun.net_state == E_NET_STATE_ONLINE)
                {
                    // delayunit = 100; //单位为1秒
                    shortIp = (SrApp.LocalIp[14] << 8) + SrApp.LocalIp[15];
                    printf("@App_PowerOn ShortIp: %d \r\n", shortIp);
                    // if (shortIp > 2 && shortIp < 3003)
                    // {
                    // 	postdelay = (0x0000FFFF & (shortIp - 2)) * delayunit;													 //根据IP地址的后16位计算延时上报时间,IP地址减2是因为表端IP地址是从3开始的
                    // 	ctimer_set(&ct_poweronpost_timer, (40 * CLOCK_SECOND) + postdelay, App_EnergyReturnpost_Callback, NULL); //掉电后延时40S才开始离散上报
                    // }
                    ctimer_set(&ct_poweronpost_timer, (40 * CLOCK_SECOND), App_EnergyReturnpost_Callback, NULL); // 入网后延时40S上报
                    SrApp.PowerOnState = 3;
                }
            }
            else
            {
            }
        }

        etimer_reset(&et2);
    }

    PROCESS_END();
}

void Apps_dyinggasp_init(void)
{
    process_start(&apps_dyinggasp_process, NULL);
}