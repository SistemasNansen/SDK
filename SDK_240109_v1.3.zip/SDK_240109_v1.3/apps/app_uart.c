#include <stdio.h>
#include <inttypes.h>
#include <string.h>

#include "contiki.h"
#include "sdk_uart.h"
#include "sdk_socket.h"
#include "sdk_wisun.h"

#include "memb.h"
#include "app_uart.h"
#include "app_type.h"
#include "app_udp.h"
#include "app.h"

PROCESS(apps_uart_process, "apps_uart_process");
bool App_Uart_ExplainDlmsData(uint8 *MsgPtr, uint16 MsgLen);

MEMB(app_uart_mem, struct app_userbuf, 2);

extern unsigned char node_mac[8];
static void App_Uart_Proc(UART_COMM_CMD uartcmd);

APP_UART_PARAM_STRUCT App_uart;

struct etimer et_uart_ackovertime;
// struct etimer et_heartbeattime;
struct ctimer ct_eventreportretry_timer;
struct ctimer ct_heartbeat_timer;
struct ctimer ct_softreset_timer;
struct ctimer ct_softreset_timer2;
struct ctimer g_ct_response_event;

static uint16_t channel = 0;
/************************************************************************************************
 * Function Name: data_copy
 * Decription   : 数据拷贝函数
 * Input        : SrcPtr-源数据缓冲区指针,DstPtr-目标数据缓冲区指针,Len-拷贝数据的长度
 * Output       : 实际拷贝数据的数量
 * Others       : 无
 ************************************************************************************************/
uint16_t data_copy(uint8_t *DstPtr, const uint8_t *SrcPtr, uint16_t Len)
{
	uint16_t i;

	// Clear_Wdt();
	if (0 == Len)
	{
		return 0;
	}

	if (DstPtr <= SrcPtr || DstPtr >= SrcPtr + Len)
	{
		// 没有内存重叠,从低地址开始复制
		for (i = 0; i < Len; i++)
		{
			*DstPtr++ = *SrcPtr++;
		}
	}
	else
	{
		// 有内存重叠,从高地址开始复制
		SrcPtr += Len - 1;
		DstPtr += Len - 1;
		for (i = 0; i < Len; i++)
		{
			*DstPtr-- = *SrcPtr--;
		}
	}
	return i;
}

/************************************************************************************************
 * Function Name: data_compare
 * Decription   : 数据比较函数
 * Input        : Buf1Ptr-数据缓冲区1指针,Buf2Ptr-数据缓冲区2指针,Len-比较数据的长度
 * Output       : TRUE-相同,FALSE-不同
 * Others       : None
 ************************************************************************************************/
uint8_t data_compare(uint8_t *Buf1Ptr, uint8_t *Buf2Ptr, uint16_t Len)
{
	uint16_t i;

	// Clear_Wdt();
	for (i = 0; i < Len; i++)
	{
		if (*(Buf1Ptr + i) != *(Buf2Ptr + i))
		{
			return 0;
		}
	}
	return 1;
}

/************************************************************************************************
 * Function Name: cal_crc16
 * Decription   : CRC校验函数
 * Input        : 被校验数据的BufPtr指针,被校验数据长度Len
 * Output       : 计算出来的校验值
 * Others       : None
 ************************************************************************************************/
uint16_t cal_crc16(const uint8_t *BufPtr, uint16_t Len)
{
	uint16_t crc16 = 0xFFFF;
	uint8_t i;
	while (Len--)
	{
		crc16 ^= *BufPtr++;
		for (i = 0; i < 8; i++)
		{
			if (crc16 & 0x0001)
			{
				crc16 >>= 1;
				crc16 ^= CRC_SEED;
			}
			else
			{
				crc16 >>= 1;
			}
		}
	}
	crc16 ^= 0xFFFF;
	return crc16;
}

/************************************************************************************************
* Function Name: apphex_string
* Decription   : 16进制转字符串
* Input        : SrcPtr-源数据缓冲区指针,DstPtr-目标数据缓冲区指针,Len-拷贝数据的长度
* Output       : true  转换成功
				 false 失败
* Others       : None
************************************************************************************************/
uint8_t apphex_string(unsigned char *SrcPtr, char *DstPtr, uint16_t Len)
{
	unsigned char hb;
	unsigned char lb;
	uint16_t i;
	for (i = 0; i < Len; i++)
	{
		hb = (SrcPtr[i] & 0xf0) >> 4;

		if (hb <= 9)
			hb += 0x30;
		else if (hb >= 10 && hb <= 15)
			hb = hb - 10 + 'A';
		else
			return 0;

		lb = SrcPtr[i] & 0x0f;
		if (lb <= 9)
			lb += 0x30;
		else if (lb >= 10 && lb <= 15)
			lb = lb - 10 + 'A';
		else
			return 0;

		DstPtr[i * 2] = hb;
		DstPtr[i * 2 + 1] = lb;
	}
	return 1;
}

void App_SoftResetTimer_Callback(void *parma)
{
	wisun_reboot();
}

void App_uart_recv_cb(const char *data, unsigned int len)
{
	uint16_t startpos;
	uint16_t fcs;
	uint16_t datalen;
	uint8_t *frameP;

	App_uart.recvlen = data_copy(App_uart.recvbuf, data, len); // 获取数据长度

	// 如果串口收到了数据
	if (App_uart.recvlen >= 6) // 小于最小长度则抛弃数据
	{
		for (startpos = 0; startpos < App_uart.recvlen - 6; startpos++) // 需找到有效数据的开始位置并进行CRC校验
		{
			if (0x02 == App_uart.recvbuf[startpos]) // 检测帧头
			{
				break;
			}
		}

		if (startpos > App_uart.recvlen - 6) // 长度检测
		{
			memset(App_uart.recvbuf, 0, APP_UART_BUFSIZE);
			App_uart.recvlen = 0;
			return;
		}

		frameP = &App_uart.recvbuf[startpos];
		datalen = frameP[1] * 256 + frameP[2];
		datalen = datalen & 0x1FFF;
		fcs = cal_crc16((uint8_t *)(frameP + 1), App_uart.recvlen - startpos - 3);					   // 从length 到userdata计算CRC
		if (frameP[3 + datalen - 1] != (uint8_t)(fcs >> 8) || frameP[3 + datalen - 2] != (uint8_t)fcs) // 检测CRC
		{
			memset(App_uart.recvbuf, 0, APP_UART_BUFSIZE);
			App_uart.recvlen = 0;
			return;
		}

		App_Uart_ExplainDlmsData(frameP, datalen + 3);
		memset(App_uart.recvbuf, 0, APP_UART_BUFSIZE);
		App_uart.recvlen = 0;
	}
	else
	{
		memset(App_uart.recvbuf, 0, APP_UART_BUFSIZE);
		App_uart.recvlen = 0;
	}
}

/************************************************************************************************
 * Function Name: App_HandleDataResponse
 * Decription   : Trans app data for response to remote
 * Input        : dataP-payload pointer,dataLen-payload length
 * Output       : None
 * Others       : None
 ************************************************************************************************/
void App_HandleDataResponse(uint8_t *dataP, uint16_t dataLen)
{
	// if (wisun.net_state == E_NET_STATE_OFFLINE)
	// {
	// 	return;
	// }
	// else
	{
#if (APP_DATA_HEXSTRING == 1)

		if (TRUE == apphex_string(dataP, App_udp.sendbuf, dataLen))
		{
			App_udp.sendlen = dataLen * 2;
		}
		else
		{
			return;
		}

#else

		App_udp.sendlen = data_copy(App_udp.sendbuf, dataP, dataLen);

#endif
		process_post(&apps_udp_process, PROCESS_EVENT_UARTRECV, NULL);
	}
}

/************************************************************************************************
 * Function Name: App_HandleStartEventReportFrm
 * Decription   : A EventReport Has Happened,Trans it or not to remote on base NetState
 * Input        : dataP-payload pointer,dataLen-payload length
 * Output       : None
 * Others       : None
 ************************************************************************************************/
void App_HandleRetryEventReportFrm(void *param)
{
	uint8_t resault[2] = {0};
	if (wisun.net_state == E_NET_STATE_OFFLINE && SrApp.RetryCount++ < 2)
	{
		ctimer_set(&ct_eventreportretry_timer, 120 * CLOCK_SECOND, App_HandleRetryEventReportFrm, NULL); // 开启120秒定时器
	}
	else if (wisun.net_state == E_NET_STATE_OFFLINE && SrApp.RetryCount >= 2)
	{
		resault[0] = 0x00;
		resault[1] = 0x01;
		SrApp.RetryCount = 0;
		App_Uart_CreateDlmsData(0x88, resault, sizeof(resault));
	}
	else
	{
		SrApp.RetryCount = 0;

#if (APP_DATA_HEXSTRING == 1)

		if (TRUE == apphex_string(SrApp.TransdataBuf, App_udp.sendbuf, SrApp.TransdataLen))
		{
			App_udp.sendlen = SrApp.TransdataLen * 2;
		}
		else
		{
			return;
		}

#else
		App_udp.sendlen = data_copy(App_udp.sendbuf, SrApp.TransdataBuf, SrApp.TransdataLen);
#endif

		process_post(&apps_udp_process, PROCESS_EVENT_EVENTREPORT, NULL);

		App_Uart_CreateDlmsData(0x88, resault, sizeof(resault));
	}
}

void response_event_result()
{
	uint8_t result[2] = {0};

	if (wisun.net_state == E_NET_STATE_OFFLINE)
	{
		result[1] = 0x01;
	}
	App_Uart_CreateDlmsData(0x88, result, sizeof(result));
	ctimer_set(&g_ct_response_event, 2 * CLOCK_SECOND, NULL, NULL);
}

/************************************************************************************************
 * Function Name: App_HandleStartEventReportFrm
 * Decription   : A EventReport Has Happened,Trans it or not to remote on base NetState
 * Input        : None
 * Output       : None
 * Others       : None
 ************************************************************************************************/
void App_HandleStartEventReportFrm(void)
{
	SrApp.RetryCount = 0;
	if (wisun.net_state == E_NET_STATE_OFFLINE)
	{
		ctimer_set(&ct_eventreportretry_timer, 120 * CLOCK_SECOND, App_HandleRetryEventReportFrm, NULL); // 开启120秒定时器
	}
	else
	{

#if (APP_DATA_HEXSTRING == 1)

		if (TRUE == apphex_string(SrApp.TransdataBuf, App_udp.sendbuf, SrApp.TransdataLen))
		{
			App_udp.sendlen = SrApp.TransdataLen * 2;
		}
		else
		{
			resault[0] = 0x00;
			resault[1] = 0x01;
			App_Uart_CreateDlmsData(0x88, resault, sizeof(resault));
			return;
		}

#else
		App_udp.sendlen = data_copy(App_udp.sendbuf, SrApp.TransdataBuf, SrApp.TransdataLen);
		process_post(&apps_udp_process, PROCESS_EVENT_EVENTREPORT, NULL);
#endif
		ctimer_set(&g_ct_response_event, 2 * CLOCK_SECOND, response_event_result, NULL);
	}
}

/************************************************************************************************
 * Function Name: App_HandleStartEventReportFrm2
 * Decription   : A EventReport Has Happened,Trans it or not to remote on base NetState
 * Input        : None
 * Output       : None
 * Others       : 此函数主要用来作为掉电信息串口方式上报使用
 ************************************************************************************************/
void App_HandleStartEventReportFrm2(void)
{
	uint8_t resault[2] = {0};
	uint32 postdelay;
	uint32 delayunit;
	uint16 shortIp;

	if (App_udp.sendlen > 0)
	{
		resault[0] = 0x00;
		resault[1] = 0x01;
		App_Uart_CreateDlmsData(0x88, resault, sizeof(resault));
		return; // UDP发送缓冲区满，直接返回
	}

	if (wisun.net_state == E_NET_STATE_OFFLINE)
	{
		resault[0] = 0x00;
		resault[1] = 0x01;
		App_Uart_CreateDlmsData(0x88, resault, sizeof(resault));
		return;
	}
	else
	{

#if (APP_DATA_HEXSTRING == 1)

		if (TRUE == apphex_string(SrApp.TransdataBuf, App_udp.sendbuf, SrApp.TransdataLen))
		{
			App_udp.sendlen = SrApp.TransdataLen * 2;
		}
		else
		{
			resault[0] = 0x00;
			resault[1] = 0x01;
			App_Uart_CreateDlmsData(0x88, resault, sizeof(resault));
			return;
		}

#else
		App_udp.sendlen = data_copy(App_udp.sendbuf, SrApp.TransdataBuf, SrApp.TransdataLen);
#endif

		delayunit = CLOCK_SECOND; // 单位为1秒
		shortIp = (SrApp.LocalIp[14] << 8) + SrApp.LocalIp[15];
		printf("@App_ShortIp: %d \r\n", shortIp);
		if (shortIp > 2 && shortIp < 3003)
		{
			postdelay = (0x0000FFFF & (shortIp - 2)) * delayunit; // 根据IP地址的后16位计算延时上报时间,IP地址减2是因为表端IP地址是从3开始的
			ctimer_set(&ct_dyinggasppost_timer, postdelay, App_dyinggasppost_Callback2, NULL);
		}

		resault[0] = 0x00;
		resault[1] = 0x00;
		App_Uart_CreateDlmsData(0x88, resault, sizeof(resault));
	}
}

/************************************************************************************************
 * Function Name: App_HandleStartEventReportFrm
 * Decription   : A EventReport Has Happened,Trans it or not to remote on base NetState
 * Input        : None
 * Output       : None
 * Others       : None
 ************************************************************************************************/
void App_HandleStartMultiEventReportFrm(void)
{
	uint8_t resault[2] = {0};

	if (wisun.net_state == E_NET_STATE_OFFLINE)
	{
		resault[0] = 0x00;
		resault[1] = 0x01;
		App_Uart_CreateDlmsData(0x7C, resault, sizeof(resault));
	}
	else
	{

#if (APP_DATA_HEXSTRING == 1)

		if (TRUE == apphex_string(SrApp.TransdataBuf, App_udp.sendbuf, SrApp.TransdataLen))
		{
			App_udp.sendlen = SrApp.TransdataLen * 2;
		}
		else
		{
			resault[0] = 0x00;
			resault[1] = 0x01;
			App_Uart_CreateDlmsData(0x7C, resault, sizeof(resault));
			return;
		}

#else
		App_udp.sendlen = data_copy(App_udp.sendbuf, SrApp.TransdataBuf, SrApp.TransdataLen);
#endif

		process_post(&apps_udp_process, PROCESS_EVENT_MULTIEVENTREPORT, NULL);
		App_Uart_CreateDlmsData(0x7C, resault, sizeof(resault));
	}
}

/************************************************************************************************
 * Function Name: Uart_CreateDlmsData
 * Decription   : 创建DLMS信息并发送给串口发送任务
 * Input        : DlmsCmd-DLMS命令,MsgPtr-信息指针,MsgLen-信息长度
 * Output       : TRUE-创建成功,FALSE-创建失败
 * Others       : 格式：0x02+长度(2)+命令(1)+数据(N)+校验(2)
 ************************************************************************************************/

bool App_Uart_CreateDlmsData(uint8 DlmsCmd, uint8 *MsgPtr, uint16 MsgLen)
{

	uint16 fcs;

	if (MsgLen > (APP_UART_BUFSIZE - 6)) // UDP数据超过UART数据域所能承受的最大长度
	{
		return 0;
	}

	App_uart.sendlen = 0;
	memset(App_uart.sendbuf, 0, APP_UART_BUFSIZE);
	App_uart.sendbuf[App_uart.sendlen++] = 0x02;
	App_uart.sendbuf[App_uart.sendlen++] = (uint8)((MsgLen + 3) >> 8); // 长度是高字节在前
	App_uart.sendbuf[App_uart.sendlen++] = (uint8)(MsgLen + 3);
	App_uart.sendbuf[App_uart.sendlen++] = DlmsCmd;
	App_uart.sendlen += data_copy(&App_uart.sendbuf[App_uart.sendlen], MsgPtr, MsgLen);
	fcs = cal_crc16(&App_uart.sendbuf[1], MsgLen + 3);
	App_uart.sendbuf[App_uart.sendlen++] = (uint8)fcs;
	App_uart.sendbuf[App_uart.sendlen++] = (uint8)(fcs >> 8);

	timerUart_write(App_uart.sendbuf, App_uart.sendlen); // 发送

	return 1;
}

void App_SoftReset_Callback(void *parma)
{
	wisun_reboot();
}

/************************************************************************************************
 * Function Name: Uart_ExplainDlmsData
 * Decription   : 解释DLMS信息并分发给各自的处理函数
 * Input        : MsgPtr-信息指针(),MsgLen-信息长度()
 * Output       : TRUE-处理成功,FALSE-处理失败
 * Others       : 格式：0x02+长度(2)+命令(1)+数据(N)+校验(2)
 ************************************************************************************************/
bool App_Uart_ExplainDlmsData(uint8 *MsgPtr, uint16 MsgLen)
{
	uint8 cmd, *dataPtr, addr[32] = {0};
	uint8 addr2[32] = {0};
	uint16 i, dataLen;
	if (MsgLen < 6)
	{
		return 0;
	}

	// 提取命令类型、数据域指针和数据域长度
	dataLen = (*(MsgPtr + 1) & 0x1F) * 256 + *(MsgPtr + 2);
	dataPtr = MsgPtr + 3;
	cmd = *dataPtr++;
	if (MsgLen < dataLen + 3 || dataLen < 3)
	{
		return 0;
	}
	dataLen -= 3;

	/*程序运行到此处，dataptr 指向数据域，datalen 指数据域的长度*/
	// 串口设置模块参数应答
	if (0x33 == cmd && Uart_SetParam == App_uart.CommCmd)
	{
		if (2 == dataLen && 0x00 == *dataPtr && 0x00 == *(dataPtr + 1))
		{
			process_post(&apps_uart_process, PROCESS_EVENT_UARTRSPCONFIRM, NULL);
		}
		return 1;
	}

	// 读取表地址命令
	if (0xA0 == cmd && Uart_GetId == App_uart.CommCmd)
	{
		if (dataLen > 3 && 0x00 == *dataPtr && 0x0B == *(dataPtr + 1) && 0 < *(dataPtr + 2))
		{
			dataLen = *(dataPtr + 2); // 地址长度
			dataPtr += 3;

			if (dataLen < 12) // 地址长度 《 12
			{
				memset(addr, 0x30, 12); // 不足12位的部分补0
				memcpy(&addr[12 - dataLen], (const uint8_t *)dataPtr, dataLen);
			}
			else // 地址长度 》= 12
			{
				memcpy(&addr[0], (const uint8_t *)(dataPtr + dataLen - 12), 12);
			}

			memset(addr2, 0, 32);
			for (i = 0; i < 12; i++)
			{
				if (i & 0x01)
				{
					addr2[i / 2] |= (addr[i] - 0x30) & 0x0F;
					// addr2[i / 2] |= (addr[i] - 0x30) << 4 & 0xF0;
				}
				else
				{
					addr2[i / 2] |= (addr[i] - 0x30) << 4 & 0xF0;
					// addr2[i / 2] |= (addr[i] - 0x30) & 0x0F;
				}
			}

			memset(SrApp.NodeAddr, 0, 6);
			memcpy(SrApp.NodeAddr, &addr2[0], 6);
			SrApp.NodeAddrLen = 6;

			printf("\r\nMeter ID:");
			for (i = 0; i < SrApp.NodeAddrLen; i++)
			{
				printf("%02x ", SrApp.NodeAddr[i]);
			}
			printf("\r\n");

			dataPtr += dataLen;

			// IP监听端口
			if (0x50 == *dataPtr && 0x02 == *(dataPtr + 1))
			{
				SrApp.ListenPort = (*(dataPtr + 2) << 8) + *(dataPtr + 3);
				dataPtr += 4;
				printf("\r\n@App_Listen Port:");
				printf("%04x ", SrApp.ListenPort);
				printf("\r\n");
			}

			// 事件端口
			if (0x50 == *dataPtr && 0x13 == *(dataPtr + 1))
			{
				SrApp.EventPort = (*(dataPtr + 2) << 8) + *(dataPtr + 3);
				dataPtr += 4;
				printf("\r\n@App_Event Port:");
				printf("%04x ", SrApp.EventPort);
				printf("\r\n");
			}

			// 事件IP
			if (0x50 == *dataPtr && 0x3A == *(dataPtr + 1))
			{
				memcpy((uint8 *)(&SrApp.EventIp), (const uint8_t *)(dataPtr + 2), 16);

				printf("\r\n@App_Event IP:");

				uip_debug_ipaddr_print(&SrApp.EventIp);
				printf("\r\n");
				dataPtr += 18;
			}

			if (0x45 == *dataPtr && 0x00 == *(dataPtr + 1))
			{
				channel = (*(dataPtr + 2) << 8) + *(dataPtr + 3) - 1;
				dataPtr = dataPtr + 4;

				if (channel >= 0 && channel < 90)
				{
					if (wisun_get_factory() == 0)
					{
						wisun_set_factory(1);
						ctimer_set(&ct_softreset_timer, 3 * CLOCK_SECOND, App_SoftResetTimer_Callback, NULL);
					}
				}
				else
				{
					if (wisun_get_factory() == 1)
					{
						wisun_set_factory(0);
						ctimer_set(&ct_softreset_timer, 3 * CLOCK_SECOND, App_SoftResetTimer_Callback, NULL);
					}
				}
			}
			else
			{
				if (wisun_get_factory() == 1)
				{
					wisun_set_factory(0);
					ctimer_set(&ct_softreset_timer, 3 * CLOCK_SECOND, App_SoftResetTimer_Callback, NULL);
				}
			}
			process_post(&apps_uart_process, PROCESS_EVENT_UARTRSPCONFIRM, NULL);
		}

		return 1;
	}

	// 串口设置模块参数应答2
	if (0x33 == cmd && Uart_SetParam2 == App_uart.CommCmd)
	{
		if (2 == dataLen && 0x00 == *dataPtr && 0x00 == *(dataPtr + 1))
		{
			process_post(&apps_uart_process, PROCESS_EVENT_UARTRSPCONFIRM, NULL);
		}
		return 1;
	}

	// 网络状态更新应答
	if (0x33 == cmd && Uart_NetStateChange == App_uart.CommCmd)
	{
		if (2 == dataLen && 0x00 == *dataPtr && 0x00 == *(dataPtr + 1))
		{
			process_post(&apps_uart_process, PROCESS_EVENT_UARTRSPCONFIRM, NULL);
		}
		return 1;
	}

	// 心跳包命令
	if (0x33 == cmd && Uart_HeartBeat == App_uart.CommCmd)
	{
		if (2 == dataLen && 0x00 == *dataPtr && 0x00 == *(dataPtr + 1))
		{
			process_post(&apps_uart_process, PROCESS_EVENT_UARTRSPCONFIRM, NULL);
		}
		return 1;
	}

	// 数据转发应答帧
	if (0x66 == cmd && dataLen > 0)
	{
		/*有合规的抄表数据交互，则延时发送心跳信息给表，防止给表造成拥塞*/
		ctimer_restart(&ct_heartbeat_timer); // 重启定时器
		APP_TRACE_STRING(Set ct_heartbeattimer);

		App_HandleDataResponse(dataPtr, dataLen);
		return 1;
	}

	// 电表发起事件上报命令
	if (0x77 == cmd && dataLen > 0)
	{
		SrApp.TransdataLen = data_copy(SrApp.TransdataBuf, dataPtr, dataLen);
		App_HandleStartEventReportFrm();
		// App_HandleStartEventReportFrm2();
		return 1;
	}

	// 电表发起多端口事件上报命令
	if (0x70 == cmd && dataLen > 0)
	{
		uint8 paramnum;
		uint8 resault[2] = {0};

		paramnum = *dataPtr++;
		if (paramnum != 2)
		{
			resault[0] = 0x00;
			resault[1] = 0x01;
			App_Uart_CreateDlmsData(0x7C, resault, sizeof(resault));
			return 0;
		}
		if (0x50 == *dataPtr && 0x80 == *(dataPtr + 1)) // 多端口事件IP
		{
			memcpy((uint8 *)(&SrApp.MultiEventIp), (const uint8_t *)(dataPtr + 2), 16);

			printf("\r\n@App_MultiEvent IP:");

			uip_debug_ipaddr_print(&SrApp.MultiEventIp);
			printf("\r\n");

			dataPtr += 18;
			dataLen -= 18;
		}
		if (0x50 == *dataPtr && 0x81 == *(dataPtr + 1)) // 多端口事件PORT
		{
			SrApp.MultiEventPort = (*(dataPtr + 2) << 8) + *(dataPtr + 3);
			printf("\r\n@App_MultiEvent Port:");
			printf("%04x ", SrApp.MultiEventPort);
			printf("\r\n");
			dataPtr += 4;
			dataLen -= 4;
		}

		SrApp.TransdataLen = data_copy(SrApp.TransdataBuf, dataPtr, dataLen);
		App_HandleStartMultiEventReportFrm();
		return 1;
	}

	// 电表发起复位模块命令
	if (0x99 == cmd)
	{
		ctimer_set(&ct_softreset_timer, 2 * CLOCK_SECOND, App_SoftReset_Callback, NULL);
		App_Uart_Proc(Uart_SoftReset);
	}

	return 0;
}

static void App_Uart_Proc(UART_COMM_CMD uartcmd)
{
	uint8 *dataPtr = 0;
	uint16 dataLen = 0;
	uint16 tmplen = 0;
	// static uint8 cmdHeartBeat[] = {0x00, 0x0A, 0x04};

	uint8 ipstr[32] = {0};
	uint32 modulesn;
	// 串口设置模块参数
	if (Uart_SetParam == uartcmd)
	{
		dataPtr = memb_alloc(&app_uart_mem);

		if (dataPtr == NULL)
		{
			APP_TRACE_STRING(Uart_Proc memory allocation failed);
			return;
		}
		else
		{
			APP_TRACE_STRING(Uart_Proc memory allocation successed);
		}

		dataLen = 0;
		// 设置模块类型为RF模块
		*(dataPtr + dataLen++) = 0x00;
		*(dataPtr + dataLen++) = 0x05;
		*(dataPtr + dataLen++) = 0x14; // WISUN模块
									   //  设置硬件版本
		*(dataPtr + dataLen++) = 0x00;
		*(dataPtr + dataLen++) = 0x06;
		*(dataPtr + dataLen++) = 0x06;
		*(dataPtr + dataLen++) = 0x56;
		*(dataPtr + dataLen++) = '0';
		*(dataPtr + dataLen++) = '0';
		*(dataPtr + dataLen++) = '.';
		*(dataPtr + dataLen++) = '0';
		*(dataPtr + dataLen++) = '1';
		// 设置软件版本
		*(dataPtr + dataLen++) = 0x00;
		*(dataPtr + dataLen++) = 0x07;

		//		 *(dataPtr + dataLen++) = 0x06;
		//		 *(dataPtr + dataLen++) = 0x56;
		//		 *(dataPtr + dataLen++) = (SOFTWARE_VERSION >> 12 & 0x0F) + '0';
		//		 *(dataPtr + dataLen++) = (SOFTWARE_VERSION >> 8 & 0x0F) + '0';
		//		 *(dataPtr + dataLen++) = '.';
		//		 *(dataPtr + dataLen++) = (SOFTWARE_VERSION >> 4 & 0x0F) + '0';
		//		 *(dataPtr + dataLen++) = (SOFTWARE_VERSION & 0x0F) + '0';

		tmplen = strlen(wisun_get_software());
		*(dataPtr + dataLen++) = tmplen;									   // 软件版本信息长度
		dataLen += data_copy(dataPtr + dataLen, wisun_get_software(), tmplen); // 软件版本信息

		// 设置厂商类型为sunray
		*(dataPtr + dataLen++) = 0x00;
		*(dataPtr + dataLen++) = 0x08;
		*(dataPtr + dataLen++) = 0x0B;

		// 设置SN号
		*(dataPtr + dataLen++) = 0x00;
		*(dataPtr + dataLen++) = 0x0E;

		modulesn = wisun_get_sn();
		memset(ipstr, 0, 32);
		sprintf((char *)ipstr, "%012lu", modulesn);

		*(dataPtr + dataLen++) = strlen(ipstr);
		dataLen += data_copy((uint8 *)(dataPtr + dataLen), (const uint8_t *)ipstr, strlen(ipstr));

		// 推送在线状态
		*(dataPtr + dataLen++) = 0x50;
		*(dataPtr + dataLen++) = 0x09;

		if (wisun.net_state == E_NET_STATE_ONLINE)
		{
			*(dataPtr + dataLen++) = 0xC3; // comm_mode
		}
		else
		{
			*(dataPtr + dataLen++) = 0x03; // comm_mode
		}

		// 打包
		App_Uart_CreateDlmsData(0x22, dataPtr, dataLen);
		memb_free(&app_uart_mem, dataPtr);
		return;
	}
	// 读取电表地址
	if (Uart_GetId == uartcmd)
	{
		App_Uart_CreateDlmsData(0xA1, NULL, 0);
		return;
	}

	// 串口设置模块参数2
	if (Uart_SetParam2 == uartcmd)
	{
		dataPtr = memb_alloc(&app_uart_mem);

		if (dataPtr == NULL)
		{
			APP_TRACE_STRING(Uart_Proc memory allocation failed);
			return;
		}
		else
		{
			APP_TRACE_STRING(Uart_Proc memory allocation successed);
		}

		dataLen = 0;
		// 设置模块类型为RF模块
		*(dataPtr + dataLen++) = 0x00;
		*(dataPtr + dataLen++) = 0x05;
		*(dataPtr + dataLen++) = 0x14; // WISUN模块
									   //  设置硬件版本
		*(dataPtr + dataLen++) = 0x00;
		*(dataPtr + dataLen++) = 0x06;
		*(dataPtr + dataLen++) = 0x06;
		*(dataPtr + dataLen++) = 0x56;
		*(dataPtr + dataLen++) = '0';
		*(dataPtr + dataLen++) = '0';
		*(dataPtr + dataLen++) = '.';
		*(dataPtr + dataLen++) = '0';
		*(dataPtr + dataLen++) = '1';
		// 设置软件版本
		*(dataPtr + dataLen++) = 0x00;
		*(dataPtr + dataLen++) = 0x07;

		//		 *(dataPtr + dataLen++) = 0x06;
		//		 *(dataPtr + dataLen++) = 0x56;
		//		 *(dataPtr + dataLen++) = (SOFTWARE_VERSION >> 12 & 0x0F) + '0';
		//		 *(dataPtr + dataLen++) = (SOFTWARE_VERSION >> 8 & 0x0F) + '0';
		//		 *(dataPtr + dataLen++) = '.';
		//		 *(dataPtr + dataLen++) = (SOFTWARE_VERSION >> 4 & 0x0F) + '0';
		//		 *(dataPtr + dataLen++) = (SOFTWARE_VERSION & 0x0F) + '0';

		tmplen = strlen(wisun_get_software());
		*(dataPtr + dataLen++) = tmplen;									   // 软件版本信息长度
		dataLen += data_copy(dataPtr + dataLen, wisun_get_software(), tmplen); // 软件版本信息

		// 设置厂商类型为sunray
		*(dataPtr + dataLen++) = 0x00;
		*(dataPtr + dataLen++) = 0x08;
		*(dataPtr + dataLen++) = 0x0B;

		// 设置SN号
		*(dataPtr + dataLen++) = 0x00;
		*(dataPtr + dataLen++) = 0x0E;

		modulesn = wisun_get_sn();
		memset(ipstr, 0, 32);
		sprintf((char *)ipstr, "%012lu", modulesn);

		*(dataPtr + dataLen++) = strlen(ipstr);
		dataLen += data_copy((uint8 *)(dataPtr + dataLen), (const uint8_t *)ipstr, strlen(ipstr));

		// 设置MAC地址
		*(dataPtr + dataLen++) = 0x00;
		*(dataPtr + dataLen++) = 0x12;
		*(dataPtr + dataLen++) = 0x08;
		dataLen += data_copy((uint8 *)(dataPtr + dataLen), (const uint8_t *)node_mac, 8);

		// 打包
		App_Uart_CreateDlmsData(0x22, dataPtr, dataLen);
		memb_free(&app_uart_mem, dataPtr);
		return;
	}

	if (Uart_NetStateChange == uartcmd)
	{
		dataPtr = memb_alloc(&app_uart_mem);

		if (dataPtr == NULL)
		{
			APP_TRACE_STRING(Uart_Proc memory allocation failed);
			return;
		}
		else
		{
			APP_TRACE_STRING(Uart_Proc memory allocation successed);
		}

		dataLen = 0;
		// 设置 comm_mode
		*(dataPtr + dataLen++) = 0x50;
		*(dataPtr + dataLen++) = 0x09;

		if (wisun.net_state == E_NET_STATE_ONLINE)
		{
			*(dataPtr + dataLen++) = 0xC3; // comm_mode

			// modem_ip
			*(dataPtr + dataLen++) = 0x50;
			*(dataPtr + dataLen++) = 0x39;
			dataLen += data_copy(dataPtr + dataLen, (const uint8_t *)&wisun.local_ip, 16);
		}
		else
		{
			*(dataPtr + dataLen++) = 0x03; // comm_mode
		}

		// 打包
		App_Uart_CreateDlmsData(0x22, dataPtr, dataLen);
		memb_free(&app_uart_mem, dataPtr);
		return;
	}

	// 发送心跳包
	if (Uart_HeartBeat == uartcmd)
	{
		//		cmdHeartBeat[2] =  wisun.net_state == E_NET_STATE_ONLINE ? 0x04 : 0x05;
		//		App_Uart_CreateDlmsData(0x22, cmdHeartBeat, sizeof(cmdHeartBeat));
		//		return;

		dataPtr = memb_alloc(&app_uart_mem);

		if (dataPtr == NULL)
		{
			APP_TRACE_STRING(Uart_Proc memory allocation failed);
			return;
		}
		else
		{
			APP_TRACE_STRING(Uart_Proc memory allocation successed);
		}

		dataLen = 0;
		// 设置 comm_mode
		*(dataPtr + dataLen++) = 0x50;
		*(dataPtr + dataLen++) = 0x09;

		if (wisun.net_state == E_NET_STATE_ONLINE)
		{
			*(dataPtr + dataLen++) = 0xC3; // comm_mode
		}
		else
		{
			*(dataPtr + dataLen++) = 0x03; // comm_mode
		}

		// 设置SN号
		*(dataPtr + dataLen++) = 0x00;
		*(dataPtr + dataLen++) = 0x0E;

		modulesn = wisun_get_sn();
		memset(ipstr, 0, 32);
		sprintf((char *)ipstr, "%012lu", modulesn);

		*(dataPtr + dataLen++) = strlen(ipstr);
		dataLen += data_copy((uint8 *)(dataPtr + dataLen), (const uint8_t *)ipstr, strlen(ipstr));

		//			// modem_ip
		//			*(dataPtr + dataLen++) = 0x50;
		//			*(dataPtr + dataLen++) = 0x39;
		//			dataLen += data_copy(dataPtr + dataLen, (const uint8_t *) SrApp.LocalIp, 16);
		//			// event_ip
		//			*(dataPtr + dataLen++) = 0x50;
		//			*(dataPtr + dataLen++) = 0x3A;
		//			dataLen += data_copy(dataPtr + dataLen, (const uint8_t *) (&SrApp.EventIp), 16);

		// 打包
		App_Uart_CreateDlmsData(0x22, dataPtr, dataLen);
		memb_free(&app_uart_mem, dataPtr);
		return;
	}

	// 发送软复位应答
	if (Uart_SoftReset == uartcmd)
	{

		dataPtr = memb_alloc(&app_uart_mem);

		if (dataPtr == NULL)
		{
			APP_TRACE_STRING(Uart_Proc memory allocation failed);
			return;
		}
		else
		{
			APP_TRACE_STRING(Uart_Proc memory allocation successed);
		}

		dataLen = 0;
		*(dataPtr + dataLen++) = 0;
		*(dataPtr + dataLen++) = 0;
		App_Uart_CreateDlmsData(0xAA, dataPtr, dataLen);
		memb_free(&app_uart_mem, dataPtr);
		return;
	}
}

void App_HeartbeatTimer_Callback(void *parma)
{
	process_post(&apps_uart_process, PROCESS_EVENT_HEARTBEAT, NULL);
	APP_TRACE_STRING(Post HeartBeat Event);
}

PROCESS_THREAD(apps_uart_process, ev, data)
{
	uint8 i;
	/**********************************************
	UART任务：
	1.配置模块参数
	2.读表地址ID
	3.设置MAC_ID
	4.发送事件(配置完成事件
	5.事件上报
	6.发送事件（事件上报完成
	7.抄表（BR--LN--uart
	8.发送事件(抄表事件完成
   ***************************************************/

	PROCESS_BEGIN();
	ctimer_set(&ct_softreset_timer2, 24 * 3600 * CLOCK_SECOND, App_SoftReset_Callback, NULL);

	timerUart_init(9600, UARTPARITY_NONE, App_uart_recv_cb);

	memb_init(&app_uart_mem);

	App_uart.CommCmd = Uart_SetParam;

	while (1)
	{
		switch (App_uart.CommCmd)
		{
		case Uart_SetParam:
			App_Uart_Proc(Uart_SetParam); // 封包，发送
			APP_TRACE_STRING(Send Set_parma);
			memset(App_uart.sendbuf, 0, APP_UART_BUFSIZE); // 清包
			App_uart.sendlen = 0;
			etimer_set(&et_uart_ackovertime, 5 * CLOCK_SECOND); // 开启定时器
			break;

		case Uart_GetId:
			App_Uart_Proc(Uart_GetId);			// 封包.发送
			APP_TRACE_STRING(Send Get_meterId); // 调试LOG

			memset(App_uart.sendbuf, 0, APP_UART_BUFSIZE); // 清包
			App_uart.sendlen = 0;
			etimer_set(&et_uart_ackovertime, 2 * CLOCK_SECOND); // 开启定时器
			break;

		case Uart_SetParam2:
			App_Uart_Proc(Uart_SetParam2); // 封包，发送
			APP_TRACE_STRING(Send Set_parma2);
			memset(App_uart.sendbuf, 0, APP_UART_BUFSIZE); // 清包
			App_uart.sendlen = 0;
			etimer_set(&et_uart_ackovertime, 5 * CLOCK_SECOND); // 开启定时器
			break;

		case Uart_NetStateChange:
			App_Uart_Proc(Uart_NetStateChange);			   // 封包
			APP_TRACE_STRING(Send NetState);			   // 调试LOG
			memset(App_uart.sendbuf, 0, APP_UART_BUFSIZE); // 清包
			App_uart.sendlen = 0;
			etimer_set(&et_uart_ackovertime, 5 * CLOCK_SECOND); // 开启定时器
			break;

		case Uart_HeartBeat:
			App_Uart_Proc(Uart_HeartBeat);	  // 封包
			APP_TRACE_STRING(Send HeartBeat); // 调试LOG

			memset(App_uart.sendbuf, 0, APP_UART_BUFSIZE); // 清包
			App_uart.sendlen = 0;
			etimer_set(&et_uart_ackovertime, 5 * CLOCK_SECOND); // 开启定时器
			break;

		case Uart_Forward:

			break;

		default:

			break;
		}

		// 等待表端 UART正确响应或者响应超时
		PROCESS_WAIT_EVENT_UNTIL((ev == PROCESS_EVENT_TIMER || ev == PROCESS_EVENT_UARTRSPCONFIRM || ev == PROCESS_EVENT_HEARTBEAT || ev == PROCESS_EVENT_NETSTATECHANGE));

		if (ev == PROCESS_EVENT_TIMER)
		{
			if (etimer_expired(&et_uart_ackovertime))
			{
				APP_TRACE_STRING(Uart Ack Over Time);
				App_uart.CommCmd = App_uart.CommCmd;
			}
		}
		else if (ev == PROCESS_EVENT_UARTRSPCONFIRM)
		{
			APP_TRACE_STRING(Uart Ack Confirm);
			etimer_stop(&et_uart_ackovertime); // 停止串口应答超时定时器
			if (App_uart.CommCmd == Uart_SetParam)
			{
				App_uart.CommCmd = Uart_GetId;
			}
			else if (App_uart.CommCmd == Uart_GetId)
			{
				// 准备设置MAC地址
				for (i = 0; i < 6; i++)
				{

					SrApp.MacAddr[i] = SrApp.NodeAddr[i];
				}
				wisun_set_mac(SrApp.MacAddr, 6);

				App_uart.CommCmd = Uart_SetParam2;
			}
			else if (App_uart.CommCmd == Uart_SetParam2)
			{
				App_uart.CommCmd = Uart_Forward;
				ctimer_set(&ct_heartbeat_timer, 10 * 60 * CLOCK_SECOND, App_HeartbeatTimer_Callback, NULL);
				APP_TRACE_STRING(Set ct_hearbeattimer);

				wisun_start_register();
				wisun_set_frequence(channel);
				process_post(&apps_udp_process, PROCESS_EVENT_SETMACIDCOMPLETE, NULL); // 发送 MAC 地址设置完成事件
			}
			else if (App_uart.CommCmd == Uart_NetStateChange)
			{
				App_uart.CommCmd = Uart_Forward;
				ctimer_restart(&ct_heartbeat_timer);
				APP_TRACE_STRING(ReStart ct_hearbeattimer);
			}
			else if (App_uart.CommCmd == Uart_HeartBeat)
			{
				App_uart.CommCmd = Uart_Forward;
				ctimer_set(&ct_heartbeat_timer, 10 * 60 * CLOCK_SECOND, App_HeartbeatTimer_Callback, NULL);
				APP_TRACE_STRING(Set ct_hearbeattimer);
			}
		}
		else if (ev == PROCESS_EVENT_NETSTATECHANGE)
		{
			APP_TRACE_STRING(Uart Send NetState);
			App_uart.CommCmd = Uart_NetStateChange;
		}
		else if (ev == PROCESS_EVENT_HEARTBEAT)
		{
			APP_TRACE_STRING(Uart Send HeartBeat);
			App_uart.CommCmd = Uart_HeartBeat;
		}
	}

	PROCESS_END();
}

void App_uart_init(void)
{
	process_start(&apps_uart_process, NULL);
}
