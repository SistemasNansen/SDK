#include <stdio.h>
#include <inttypes.h>
#include <string.h>

#include "contiki.h"
#include "sdk_uart.h"
#include "sdk_socket.h"
#include "sdk_wisun.h"

#include "memb.h"
#include "app.h"
#include "app_uart.h"
#include "app_type.h"

extern struct ctimer ct_softreset_timer2;
extern struct ctimer g_ct_response_event;
PROCESS(apps_udp_process, "apps_udp_process");
APP_UDP_PARAM_STRUCT App_udp;
uint16_t file_protocol_parse(const char *in_data, uint32_t size, uint8_t * out_data);

static void udp_recv_cb(
	struct udp_socket *c,
	void *ptr,
	const uip_ipaddr_t *source_addr,
	uint16_t source_port,
	const uip_ipaddr_t *dest_addr,
	uint16_t dest_port,
	const uint8_t *data,
	uint16_t datalen)
{
	uint8_t i;

	// App_udp.c = c;
	for (i = 0; i < 16; i++)
	{
		memcpy((uint8_t *)(&App_udp.srcaddr), (const uint8_t *)source_addr, 16);
		memcpy((uint8_t *)(&App_udp.dstaddr), (const uint8_t *)dest_addr, 16);
	}
	App_udp.srcport = source_port;
	App_udp.dstport = dest_port;

	// printf("\r\n@App_UDP_RECV DstIp=");
	// uip_debug_ipaddr_print(&App_udp.dstaddr);
	// printf("\r\n@App_UDP_RECV DstPort= %d", App_udp.dstport);

	// printf("\r\n@App_UDP_RECV SrcIp=");
	// uip_debug_ipaddr_print(&App_udp.srcaddr);
	// printf("\r\n@App_UDP_RECV SrcPort= %d", App_udp.srcport);

	if (0xf0 == data[0] || 0xf2 == data[0])
	{
		App_udp.sendlen = file_protocol_parse(data, datalen, App_udp.sendbuf);
		if (App_udp.sendlen)
		{
			udp_socket_sendto(c, App_udp.sendbuf, App_udp.sendlen, &App_udp.srcaddr, App_udp.srcport);
		}
		return;
	} 

	memcpy(App_udp.recvbuf, data, datalen);
	App_udp.recvlen = datalen;

	if ((wisun.net_state == E_NET_STATE_ONLINE) || wisun_get_factory())
	{
		process_post(&apps_udp_process, PROCESS_EVENT_UDPRECV, NULL);
	}
}

PROCESS_THREAD(apps_udp_process, ev, data)
{
	PROCESS_BEGIN();

	PROCESS_WAIT_EVENT_UNTIL(ev == PROCESS_EVENT_SETMACIDCOMPLETE);

	// register udp
	if (udp_socket_register(&SrApp.Udp_fd, NULL, udp_recv_cb) == -1)
	{
		printf("udp_socket_register fail\n");
	}
	else
	{
		if (udp_socket_bind(&SrApp.Udp_fd, SrApp.ListenPort) == -1)
		{
			printf("udp_socket_bind fail\n");
		}
		else
		{
			printf("udp_socket_bind success\n");
		}
	}

	while (1)
	{
		PROCESS_WAIT_EVENT();
		if (ev == PROCESS_EVENT_UDPRECV) // UDP数据接收事件标志
		{
			//转发抄表数据下行
			App_Uart_CreateDlmsData(0x55, App_udp.recvbuf, App_udp.recvlen);
			ctimer_restart(&g_ct_response_event);
			memset(App_udp.recvbuf, 0, APP_UDP_BUFSIZE);
			App_udp.recvlen = 0;

			ctimer_restart(&ct_softreset_timer2);
		}
		else if (ev == PROCESS_EVENT_UARTRECV) //抄表数据响应
		{
			//转发抄表响应数据上行
			if (App_udp.dstport == SrApp.ListenPort)
			{
				udp_socket_sendto(&SrApp.Udp_fd, App_udp.sendbuf, App_udp.sendlen, &App_udp.srcaddr, App_udp.srcport);
			}
			else
			{
			}

			//清UDP发送缓冲区
			memset(App_udp.sendbuf, 0, APP_UDP_BUFSIZE);
			App_udp.sendlen = 0;
		}

		else if (ev == PROCESS_EVENT_EVENTREPORT) //电表事件上报
		{
			//转发事件上报数据上行
			udp_socket_sendto(&SrApp.Udp_fd, App_udp.sendbuf, App_udp.sendlen, &SrApp.EventIp, SrApp.EventPort);

			//清UDP发送缓冲区
			memset(App_udp.sendbuf, 0, APP_UDP_BUFSIZE);
			App_udp.sendlen = 0;
		}
		else if (ev == PROCESS_EVENT_POWERDOWNREPORT) //电表掉电事件上报
		{
			//转发掉电事件上报数据上行
			udp_socket_sendto(&SrApp.Udp_fd, App_udp.sendbuf, App_udp.sendlen, &SrApp.EventIp, SrApp.EventPort);

			//清UDP发送缓冲区
			memset(App_udp.sendbuf, 0, APP_UDP_BUFSIZE);
			App_udp.sendlen = 0;
		}
		else if (ev == PROCESS_EVENT_POWERONREPORT) //电表上电事件上报
		{
			//转发上电事件上报数据上行
			udp_socket_sendto(&SrApp.Udp_fd, App_udp.sendbuf, App_udp.sendlen, &SrApp.EventIp, SrApp.EventPort);

			//清UDP发送缓冲区
			memset(App_udp.sendbuf, 0, APP_UDP_BUFSIZE);
			App_udp.sendlen = 0;
		}

		else if (ev == PROCESS_EVENT_MULTIEVENTREPORT) //电表多端口事件上报
		{
			//转发多端口事件上报数据上行
			udp_socket_sendto(&SrApp.Udp_fd, App_udp.sendbuf, App_udp.sendlen, &SrApp.MultiEventIp, SrApp.MultiEventPort);

			//清UDP发送缓冲区
			memset(App_udp.sendbuf, 0, APP_UDP_BUFSIZE);
			App_udp.sendlen = 0;
		}
	}
	PROCESS_END();
}

void App_udp_init(void)
{
	process_start(&apps_udp_process, NULL);
}
