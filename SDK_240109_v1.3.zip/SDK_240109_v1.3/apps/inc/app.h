#ifndef _APP_H_
#define _APP_H_

/*********************************MACRO DEFINE*****************************************
**********************************       Author lxf
******************************************/
#define APP_SOFT_WARE_VERSION "E.ME00-RW24.BR.V1.00.17"

//new
#if 0
#define APP_DYINGGASP_EVENT_PORT IOA
#define APP_DYINGGASP_EVENT_PIN 4
#define APP_NET_LED_PORT IOA
#define APP_NET_LED_PIN 5
#define APP_TX_LED_PORT IOA
#define APP_TX_LED_PIN 7
#define APP_RX_LED_PORT IOA
#define APP_RX_LED_PIN 6
#else
//old
#define APP_DYINGGASP_EVENT_PORT IOB
#define APP_DYINGGASP_EVENT_PIN 12
#define APP_NET_LED_PORT IOB
#define APP_NET_LED_PIN 13
#define APP_TX_LED_PORT IOB
#define APP_TX_LED_PIN 14
#define APP_RX_LED_PORT IOB
#define APP_RX_LED_PIN 15
#endif


#define PROCESS_EVENT_NETSTATECHANGE 0x72 //网络状态变化事件标志

#define PROCESS_EVENT_MULTIEVENTREPORT 0x73 //上报多端口事件上报的事件标志

#define PROCESS_EVENT_UDPUPDATERECV 0x74 //接收到UDP数据升级事件标志

#define PROCESS_EVENT_POWERONREPORT 0x75 //上报上电事件的事件标志

#define PROCESS_EVENT_POWERDOWNREPORT 0x76 //上报掉电事件的事件标志

#define PROCESS_EVENT_HEARTBEAT 0x77 //收到心跳事件标志

#define PROCESS_EVENT_UARTRSPCONFIRM 0x78 //收到表正确应答事件标志

#define PROCESS_EVENT_EVENTREPORT 0x79 //上报事件的事件标志

#define PROCESS_EVENT_UDPRECV 0x7A //接收到UDP数据事件标志

#define PROCESS_EVENT_UARTSEND 0x7B //发送串口透传数据事件标志

#define PROCESS_EVENT_UARTRECV 0x7C //接收串口透传数据事件标志

#define PROCESS_EVENT_NETCOMPLETE 0x7D //入网完成的事件标志

#define PROCESS_EVENT_SETMACIDCOMPLETE 0x7E //设置MAC ID完成事件

#define PROCESS_EVENT_AUTH_RESPONSE 0x7F //双向鉴权
#define PROCESS_EVENT_AUTH_INIT 0x80 //鉴权初始化

#define APP_UDP_LOCAL_PORT 25010
#define APP_UDP_REMOTE_PORT 25010

#define APP_UDP_BUFSIZE 640
#define APP_USER_BUF_SIZE 640

#define LONG_ADDR_SIZE 6
#define APP_DATA_HEXSTRING 0

#define APP_TRACE_ID "@App_"
#define APP_TRACE_STRING(a) printf("@App_" #a "\r\n")

#define AUTH_BUFSIZE 1200
/*********************************MACRO DEFINE END***************************************/

/*********************************ENUM DEFINE*****************************************
**********************************       Author lxf
******************************************/


/*********************************ENUM DEFINE END***************************************/

/*********************************STRUCT DEFINE*****************************************
**********************************       Author lxf
******************************************/

struct app_userbuf
{
	uint8_t buff[APP_USER_BUF_SIZE];
};

typedef struct
{
	uint16_t recvlen;
	uint8_t recvbuf[APP_UDP_BUFSIZE];
	uint16_t sendlen;
	uint8_t sendbuf[APP_UDP_BUFSIZE];
	//	uint16_t  	recvlen2;
	//	uint8_t 	recvbuf2[APP_UDP_BUFSIZE];

	uip_ipaddr_t srcaddr;
	uip_ipaddr_t dstaddr;
	uint16_t srcport;
	uint16_t dstport;
} APP_UDP_PARAM_STRUCT;

//APP运行参数结构体
typedef struct
{
	uint8_t NodeAddr[6];					 //表地址
	uint8_t NodeAddrLen;					 //表地址长度
	uint8_t MacAddr[6];						 //MAC地址
	uip_ipaddr_t Peer_addr;					 //远程目标IPD地址
	struct udp_socket Udp_fd;				 //UDP socket
	struct udp_socket Udp_Updatefd;			 //UDP socket
	uint8_t BorderIp[16];					 //BR的IP
	uint8_t LocalIp[16];					 //当前IP
	uint8_t ManageIp[16];					 //网络管理平台IP
	uint8_t TransdataBuf[APP_USER_BUF_SIZE]; //App trans data buf
	uint16_t TransdataLen;					 // App trans data length
	uint8_t RetryCount;						 // App retry trans data Counter
	uint8_t DyingState;						 //用于掉电上报标记
	uint8_t PowerOnState;					 //用于上电上报标记
	uint8_t FrameSn;
	uint8_t Debug;

	uint16_t ListenPort;  //监听IP端口
	uint16_t EventPort;	  //事件IP端口
	uint16_t UpdatePort;  //表端升级端口
	uip_ipaddr_t EventIp; //事件IP

	uint16_t MultiEventPort;   //多端口事件PORT
	uip_ipaddr_t MultiEventIp; //多端口事件IP
} APP_PARAM_STRUCT;


/*********************************STRUCT DEFINE END***************************************/

/********************************* VARIABLE DECLARE*****************************************
**********************************       Author lxf
*********************************************/

extern APP_PARAM_STRUCT SrApp;
extern APP_UDP_PARAM_STRUCT App_udp;
extern struct ctimer ct_dyinggasppost_timer;

/*********************************VARIABLE DECLARE END*************************************/

/********************************* FUNCTION DECLARE*****************************************
**********************************       Author lxf
*********************************************/

void App_dyinggasppost_Callback2(void *parma);

/*********************************FUNCTION DECLARE END*************************************/

#endif
