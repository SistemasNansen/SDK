#ifndef _APP_UART_H_
#define _APP_UART_H_

#include <stdbool.h>

#include "sdk_socket.h"

#include "app_type.h"

#define APP_UART_BUFSIZE 640

// 和电表通信指令信息
typedef enum
{
    Uart_SetParam = 0,   // 串口设置模块参数
    Uart_GetId,          // 串口获取电表地址
    Uart_SetParam2,      //串口设置模块参数2-用于设置新的MAC地址后，把此地址推送给电表
    Uart_HeartBeat,      // 串口发送心跳包
    Uart_NetStateChange, //串口发送网络状态信息
    Uart_Forward,        //数据转发
    Uart_SoftReset,      //软复位
} UART_COMM_CMD;

typedef struct
{
    UART_COMM_CMD CommCmd; // UART和电表通信指令
    uint16 recvlen;
    uint8 recvbuf[APP_UART_BUFSIZE];
    uint16 sendlen;
    uint8 sendbuf[APP_UART_BUFSIZE];

} APP_UART_PARAM_STRUCT;

void App_uart_init(void);
void App_uart_recv_cb(const char *data, unsigned int len);
bool App_Uart_CreateDlmsData(uint8 DlmsCmd, uint8 *MsgPtr, uint16 MsgLen);

extern struct ctimer ct_softreset_timer;
PROCESS_NAME(apps_uart_process);
#endif
