#ifndef _APP_LED_H_
#define _APP_LED_H_

#include "sdk_gpio.h"

typedef enum
{
	LED_NET = 0,
	LED_NUM,
} LED_TYPE;

typedef enum
{
	LED_ONCE,		 //单次点亮
	LED_CONST,		 //常亮
	LED_PeriodFlash, //周期闪烁
	LED_BLINK,		 //连续闪烁2次
	LED_OFF,		 //LED关闭
} LED_MODE_ENUM;

typedef struct
{
	LED_TYPE LedType;
	LED_MODE_ENUM LedMode;
	uint16_t LedOnTime;			 //Led点亮时间计数器，用在单次点亮模式和周期闪烁模式--单位10毫秒
	uint16_t LedPeriodTime;		 //led亮灭周期计数器，只用在LED周期闪烁模式  --单位10毫秒
	uint16_t Led_Flash_Count;	 //Led点亮时间计数器，用在单次点亮模式和周期闪烁模式--单位10毫秒
	uint16_t LedOnTimeConst;	 //Led点亮时间常量，用在单次点亮模式和周期闪烁模式--单位10毫秒
	uint16_t LedPeriodTimeConst; //Led亮灭周期常量，只用在LED周期闪烁模式     --单位10毫秒
} LED_STRUCT;

void App_Led_SetMode(LED_TYPE ledtype, LED_MODE_ENUM mode, uint16_t ontime, uint16_t periodtime, uint16_t flashcount);
void App_led_init(void);
#endif