#ifndef _APP_DYINGGASP_H_
#define _APP_DYINGGASP_H_

#include "contiki.h"

void Apps_dyinggasp_init(void);
#endif