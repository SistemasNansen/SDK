#ifndef _APP_UDP_H_
#define _APP_UDP_H_

#include "contiki.h"

PROCESS_NAME(apps_udp_process);
void App_udp_init(void);
#endif