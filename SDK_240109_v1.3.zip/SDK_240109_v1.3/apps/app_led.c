#include <stdio.h>
#include <inttypes.h>
#include <string.h>

#include "contiki.h"
#include "sdk_uart.h"
#include "sdk_socket.h"

#include "memb.h"
#include "app.h"
#include "app_uart.h"
#include "app_type.h"
#include "app_led.h"

PROCESS(apps_led_process, "apps_led_process");

LED_STRUCT Led[LED_NUM];

/************************************************************************************************
 * Function Name: App_Led_Init
 * Decription   : Led状态初始化函数
 * Input        : None
 * Output       : None
 * Others       : None
 ************************************************************************************************/
void App_Led_Init(void)
{
    uint8_t i;

    set_tx_led(APP_TX_LED_PORT, APP_TX_LED_PIN);
    set_rx_led(APP_RX_LED_PORT, APP_RX_LED_PIN);

    // LED初始化，上电后各亮一下
    for (i = 0; i < LED_NUM; i++)
    {
        Led[i].LedType = (LED_TYPE)i;
        Led[i].LedMode = LED_ONCE;
        Led[i].LedOnTime = 50;
    }
}

void App_Led_Net(uint8_t val)
{
    if (val == 0)
    {
        hal_gpio_high(APP_NET_LED_PORT, APP_NET_LED_PIN);
    }
    else
    {
        hal_gpio_low(APP_NET_LED_PORT, APP_NET_LED_PIN);
    }
}
/************************************************************************************************
 * Function Name: App_Led_Set
 * Decription   : Led设置函数
 * Input        : None
 * Output       : None
 * Others       : None
 ************************************************************************************************/
void App_Led_Set(LED_TYPE ledtype, uint8_t val)
{
    if (ledtype == LED_NET)
    {
        App_Led_Net(val);
    }
}

/************************************************************************************************
 * Function Name: App_Led_SetMode
 * Decription   : Led模式设置函数
 * Input        : None
 * Output       : None
 * Others       : None
 ************************************************************************************************/
void App_Led_SetMode(LED_TYPE ledtype, LED_MODE_ENUM mode, uint16_t ontime, uint16_t periodtime, uint16_t flashcount)
{
    Led[ledtype].LedMode = mode;
    Led[ledtype].LedOnTimeConst = ontime;
    Led[ledtype].LedPeriodTimeConst = periodtime;
    Led[ledtype].LedOnTime = Led[ledtype].LedOnTimeConst;
    Led[ledtype].LedPeriodTime = Led[ledtype].LedPeriodTimeConst;
    Led[ledtype].Led_Flash_Count = flashcount;
}

/************************************************************************************************
 * Function Name: App_Led_Timer_Callback
 * Decription   : Led定时中断回调函数
 * Input        : None
 * Output       : None
 * Others       : None
 ************************************************************************************************/
void App_Led_Timer_Callback(void)
{
    uint8_t i;

    for (i = 0; i < LED_NUM; i++)
    {
        switch (Led[i].LedMode)
        {
        case LED_CONST:

            break;

        case LED_OFF:

            break;

        case LED_ONCE:
            if (Led[i].LedOnTime > 0)
            {
                Led[i].LedOnTime--;
            }
            break;

        case LED_PeriodFlash:
            if (Led[i].LedOnTime > 0)
            {
                Led[i].LedOnTime--;
            }
            if (Led[i].LedPeriodTime > 0)
            {
                Led[i].LedPeriodTime--;
            }
            break;
        default:

            break;
        }
    }
}

/************************************************************************************************
 * Function Name: App_Led_Main
 * Decription   : Led运行主函数
 * Input        : None
 * Output       : None
 * Others       : None
 ************************************************************************************************/
void App_Led_Main(void)
{
    uint8_t i;

    for (i = 0; i < LED_NUM; i++)
    {
        switch (Led[i].LedMode)
        {
        case LED_CONST:
            App_Led_Set(Led[i].LedType, 1);
            break;

        case LED_ONCE:
            if (Led[i].LedOnTime > 0)
            {
                App_Led_Set(Led[i].LedType, 1);
            }
            else
            {
                Led[i].LedMode = LED_OFF;
                App_Led_Set(Led[i].LedType, 0);
            }
            break;

        case LED_PeriodFlash:
            if (Led[i].LedOnTime > 0)
            {
                App_Led_Set(Led[i].LedType, 1);
            }
            else if (Led[i].LedOnTime == 0 && Led[i].LedPeriodTime > 0)
            {
                App_Led_Set(Led[i].LedType, 0);
            }
            else if (Led[i].LedOnTime == 0 && Led[i].LedPeriodTime == 0)
            {
                Led[i].LedOnTime = Led[i].LedOnTimeConst;
                Led[i].LedPeriodTime = Led[i].LedPeriodTimeConst;
            }
            break;

        case LED_BLINK:

            if (Led[i].Led_Flash_Count > 0)
            {
                if (Led[i].LedOnTime > 0)
                {
                    App_Led_Set(Led[i].LedType, 1);
                }
                else if (Led[i].LedOnTime == 0 && Led[i].LedPeriodTime > 0)
                {
                    App_Led_Set(Led[i].LedType, 0);
                }
                else if (Led[i].LedOnTime == 0 && Led[i].LedPeriodTime == 0)
                {
                    Led[i].LedOnTime = Led[i].LedOnTimeConst;
                    Led[i].LedPeriodTime = Led[i].LedPeriodTimeConst;
                    Led[i].Led_Flash_Count--;
                }
            }
            else
            {
                Led[i].LedMode = LED_CONST; // 连续闪烁后，回归常亮
            }

            break;
        case LED_OFF:
            App_Led_Set(Led[i].LedType, 0);
            Led[i].LedOnTime = 0;
            Led[i].LedPeriodTime = 0;
            break;

        default:

            break;
        }
    }
}

PROCESS_THREAD(apps_led_process, ev, data)
{
    PROCESS_BEGIN();

    hal_gpio_output_init(APP_NET_LED_PORT, APP_NET_LED_PIN);
    App_Led_Init();

    static struct etimer et1;
    App_Led_SetMode(LED_NET, LED_PeriodFlash, 50, 200, 0);

    etimer_set(&et1, CLOCK_SECOND / 100); // 开启10毫秒定时器
    while (1)
    {

        PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&et1));
        App_Led_Main();
        App_Led_Timer_Callback();
        etimer_reset(&et1);
    }

    PROCESS_END();
}

void App_led_init(void)
{
    process_start(&apps_led_process, NULL);
}
