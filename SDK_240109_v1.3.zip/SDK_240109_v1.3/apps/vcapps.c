/**
 * Copyright (c) 2018 Technologies, Inc. All rights reserved
 * Confidential Proprietary
 *
 */
#include <stdio.h>
#include "contiki.h"
#include "sdk_socket.h"
#include "sdk_uart.h"
#include "sdk_gpio.h"
#include "sdk_wisun.h"

#include "app_dyinggasp.h"
#include "app_led.h"
#include "app_uart.h"
#include "app_udp.h"
#include "app.h"

APP_PARAM_STRUCT SrApp;

static void rpl_join_callback(const uip_ip6addr_t *device, const uip_ip6addr_t *parent, uint8_t changed, uint8_t level)
{
	uint8 *mac = wisun_get_mac();
	printf("\r\n@state= %d", wisun.net_state);
	printf("\r\n@panid= %d", wisun_get_panid());
	printf("\r\n@mac= %02x:%02x:%02x:%02x:%02x:%02x:%02x:%02x\n", *mac, *(mac+1), *(mac+2), *(mac+3), *(mac+4), *(mac+5), *(mac+6), *(mac+7));

	printf("\r\n@device= ");
	uip_debug_ipaddr_print(device);
	printf("\r\n@parent= ");
	uip_debug_ipaddr_print(parent);
	printf("\r\n@change:%d", changed);
	printf("\r\n@level:%d\n", level);
	App_Led_SetMode(LED_NET, LED_CONST, 0, 0, 0);
	process_post(&apps_uart_process, PROCESS_EVENT_NETSTATECHANGE, NULL); // 网络更新，推送网络信息给电表
}

static void rpl_leave_callback(const uip_ip6addr_t *device)
{
	printf("\r\n@leave ip=");
	uip_debug_ipaddr_print(device);
	printf("\n");
	process_post(&apps_uart_process, PROCESS_EVENT_NETSTATECHANGE, NULL); // 网络更新，推送网络信息给电表
}

/* Note: you can not rename this process */
PROCESS(main_process, "main_process");

PROCESS_THREAD(main_process, ev, data)
{
	PROCESS_BEGIN();
	printf("@main process Start\r\n");

	WISUN_HOOK.rpl_join_callback_fn = rpl_join_callback;
	WISUN_HOOK.rpl_leave_callback_fn = rpl_leave_callback;

	wisun_set_vendor("VertexCom");
	wisun_set_software(APP_SOFT_WARE_VERSION);
	printf("sw:%s\n", APP_SOFT_WARE_VERSION);
	// wisun_set_netname("vv");
	printf("netname: %s\n", wisun_get_netname());
	wisun_auth_type(E_AUTH_LOW);

	App_uart_init();
	App_led_init();
	App_udp_init();
	Apps_dyinggasp_init();
	PROCESS_END();
}

